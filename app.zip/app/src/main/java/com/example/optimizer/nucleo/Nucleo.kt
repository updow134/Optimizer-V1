package com.example.optimizer.nucleo

data class RegistroGuard(
    val id: String,
    val quando: Long,
    val operacao: String,
    val original: String,
    val aplicado: String,
    val ok: Boolean,
    val temporario: Boolean,
    val restaurado: Boolean,
    val comandoRestaurar: String,
    val detalhe: String,
)

class GuardLivro(inicial: List<RegistroGuard> = emptyList()) {
    private val itens = inicial.toMutableList()

    fun lista(): List<RegistroGuard> = itens.toList()

    fun pendentes(): List<RegistroGuard> = itens.filter {
        it.ok && it.temporario && !it.restaurado && it.comandoRestaurar.isNotBlank()
    }

    fun registrar(
        agora: Long,
        operacao: String,
        original: String,
        aplicado: String,
        ok: Boolean,
        temporario: Boolean,
        comandoRestaurar: String,
        detalhe: String,
    ): RegistroGuard {
        val item = RegistroGuard(
            id = "$agora-${itens.size}",
            quando = agora,
            operacao = operacao.take(80),
            original = original.take(300),
            aplicado = aplicado.take(300),
            ok = ok,
            temporario = temporario,
            restaurado = false,
            comandoRestaurar = comandoRestaurar.take(400),
            detalhe = detalhe.take(200),
        )
        itens.add(0, item)
        if (itens.size > 80) itens.subList(80, itens.size).clear()
        return item
    }

    fun marcarRestaurado(id: String): RegistroGuard? {
        val i = itens.indexOfFirst { it.id == id }
        if (i < 0) return null
        val novo = itens[i].copy(restaurado = true)
        itens[i] = novo
        return novo
    }
}

fun RegistroGuard.linha(): String = listOf(
    id, quando.toString(), operacao, original, aplicado,
    ok.toString(), temporario.toString(), restaurado.toString(),
    comandoRestaurar, detalhe,
).joinToString("\u001f") { it.replace("\n", " ").replace("\u001f", " ") }

fun linhaParaRegistro(linha: String): RegistroGuard? {
    val p = linha.split("\u001f")
    if (p.size < 10) return null
    val quando = p[1].toLongOrNull() ?: return null
    return RegistroGuard(
        id = p[0],
        quando = quando,
        operacao = p[2],
        original = p[3],
        aplicado = p[4],
        ok = p[5] == "true",
        temporario = p[6] == "true",
        restaurado = p[7] == "true",
        comandoRestaurar = p[8],
        detalhe = p[9],
    )
}

fun textoDoLivro(itens: List<RegistroGuard>): String =
    itens.joinToString("\n") { it.linha() }

fun livroDoTexto(texto: String): GuardLivro =
    GuardLivro(texto.lineSequence().mapNotNull { linhaParaRegistro(it) }.toList())

data class LeituraDiag(
    val shizuku: Boolean,
    val cpu: Float? = null,
    val ram: Float? = null,
    val swapMb: Int? = null,
    val tempC: Float? = null,
    val bateria: Int? = null,
    val gpu: Float? = null,
    val hz: Int? = null,
    val sdk: Int? = null,
    val fabricante: String = "",
    val modelo: String = "",
    val resolucao: String = "",
    val dpi: String = "",
)

data class Recomendacao(
    val id: String,
    val problema: String,
    val explicacao: String,
    val ajuste: String,
    val beneficio: String,
    val risco: String,
    val compativel: Boolean,
)

fun diagnosticar(l: LeituraDiag, ignorar: Set<String> = emptySet()): List<Recomendacao> {
    if (!l.shizuku) {
        return listOf(
            Recomendacao(
                "shizuku",
                "O Shizuku não está ligado",
                "Sem ele o app não lê o aparelho nem aplica ajuste.",
                "Abra o Shizuku, inicie o serviço e toque em Permitir.",
                "As ferramentas passam a funcionar.",
                "Nenhum. Não muda a tela.",
                true,
            ),
        ).filter { it.id !in ignorar }
    }
    val lista = mutableListOf<Recomendacao>()
    val ram = l.ram
    if (ram != null && ram >= 0.85f) {
        lista += Recomendacao(
            "ram",
            "Memória em ${(ram * 100).toInt()}%",
            "O que ficou aberto atrás disputa espaço com o jogo.",
            "Limpar a RAM dos apps em segundo plano.",
            "Libera memória agora. Não promete mais FPS.",
            "Um app atrás pode fechar. A lista branca e o sistema ficam de fora.",
            true,
        )
    }
    val temp = l.tempC
    val hz = l.hz
    if (temp != null && temp >= 42f && (hz == null || hz >= 90)) {
        lista += Recomendacao(
            "calor",
            "Calor em ${temp.toInt()}°",
            "A bateria está quente. Taxa alta segura esse calor por mais tempo.",
            if (hz != null && hz >= 120) "Baixar a taxa para 90 Hz." else "Ligar o perfil Economia.",
            "A tendência é esquentar menos. Não há medição de FPS aqui.",
            "A tela pode parecer menos lisa.",
            (l.sdk ?: 26) >= 26,
        )
    }
    val bat = l.bateria
    if (bat != null && bat <= 20) {
        lista += Recomendacao(
            "bateria",
            "Bateria em $bat%",
            "Com pouca carga, o sistema já começa a segurar o desempenho.",
            "Aplicar o perfil Economia.",
            "Reduz o consumo da animação e liga a economia do Android.",
            "Animações ficam mais curtas e alguns apps sincronizam menos.",
            true,
        )
    }
    val swap = l.swapMb
    if (swap != null && swap >= 400 && (ram == null || ram >= 0.7f)) {
        lista += Recomendacao(
            "swap",
            "Swap em uso: $swap MB",
            "O aparelho está usando memória lenta além da RAM.",
            "Limpar apps em segundo plano.",
            "Pode diminuir o uso de swap. Não é garantia.",
            "Apps em segundo plano fecham.",
            true,
        )
    }
    return lista.filter { it.id !in ignorar }
}

data class Perfil(
    val id: String,
    val nome: String,
    val animacao: String,
    val economia: Boolean,
    val hz: Int,
    val fixo: Boolean,
)

fun perfisOriginais(): List<Perfil> = listOf(
    Perfil("performance", "Performance", "0", false, 0, true),
    Perfil("balanceado", "Balanceado", "0.5", false, 0, true),
    Perfil("economia", "Economia", "0.5", true, 60, true),
    Perfil("personalizado", "Personalizado", "1", false, 0, true),
)

fun perfilValido(p: Perfil): Boolean =
    p.id.matches(Regex("^[a-z0-9_-]{2,24}$")) &&
        p.nome.isNotBlank() &&
        p.animacao in setOf("0", "0.5", "1") &&
        p.hz in setOf(0, 60, 90, 120)

fun previa(p: Perfil): String = buildString {
    append("Animação ${p.animacao}. ")
    append(if (p.economia) "Economia de bateria ligada. " else "Economia de bateria desligada. ")
    append(if (p.hz == 0) "Não mexe na taxa da tela." else "Taxa fixa em ${p.hz} Hz.")
}

fun comandosDoPerfil(p: Perfil): List<String> {
    if (!perfilValido(p)) return emptyList()
    if (p.id == "personalizado") return emptyList()
    val cmds = mutableListOf(
        "settings put global window_animation_scale ${p.animacao}",
        "settings put global transition_animation_scale ${p.animacao}",
        "settings put global animator_duration_scale ${p.animacao}",
        "settings put global low_power ${if (p.economia) 1 else 0}",
    )
    if (p.hz in setOf(60, 90, 120)) {
        cmds += "settings put system peak_refresh_rate ${p.hz}"
        cmds += "settings put system min_refresh_rate ${p.hz}"
    }
    return cmds
}

fun duplicarPerfil(p: Perfil, id: String, nome: String): Perfil? {
    val novo = p.copy(id = id, nome = nome.take(24), fixo = false)
    return novo.takeIf { perfilValido(it) }
}

fun excluirPerfil(lista: List<Perfil>, id: String): List<Perfil> {
    val alvo = lista.firstOrNull { it.id == id } ?: return lista
    if (alvo.fixo) return lista
    return lista.filterNot { it.id == id }
}

fun editarPerfil(lista: List<Perfil>, novo: Perfil): List<Perfil> {
    if (!perfilValido(novo)) return lista
    val atual = lista.firstOrNull { it.id == novo.id } ?: return lista
    if (atual.fixo && (novo.animacao != atual.animacao || novo.economia != atual.economia || novo.hz != atual.hz)) {
        return lista
    }
    return lista.map { if (it.id == novo.id) novo.copy(fixo = atual.fixo) else it }
}

fun restaurarTamanho(saida: String): String {
    val override = Regex("Override size:\\s*(\\d{3,5}x\\d{3,5})").find(saida)
    return if (override != null) "wm size ${override.groupValues[1]}" else "wm size reset"
}

fun restaurarDpi(saida: String): String {
    val override = Regex("Override density:\\s*(\\d{2,4})").find(saida)
    return if (override != null) "wm density ${override.groupValues[1]}" else "wm density reset"
}

fun restaurarNumero(namespace: String, chave: String, lido: String, permitidos: Set<String>): String {
    val v = lido.trim()
    return if (v in permitidos) "settings put $namespace $chave $v" else "settings delete $namespace $chave"
}

