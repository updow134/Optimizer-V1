package com.example.optimizer.ui

import android.content.pm.PackageManager
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShizukuState(val titulo: String, val detalhe: String) {
    CONECTADO("Shizuku ativo", "Permissão concedida. Todas as ferramentas liberadas."),
    SEM_PERMISSAO("Sem permissão", "Toque em Permitir para autorizar o app no Shizuku."),
    INATIVO("Shizuku não está rodando", "Inicie o Shizuku via Depuração sem fio ou ADB.")
}

data class Resultado(val ok: Boolean, val saida: String)

object ShizukuManager {
    const val REQUEST_CODE: Int = 1001
    private const val LIMITE_SAIDA: Int = 20_000

    fun estado(): ShizukuState {
        return try {
            if (!Shizuku.pingBinder()) {
                ShizukuState.INATIVO
            } else if (Shizuku.isPreV11()) {
                ShizukuState.INATIVO
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                ShizukuState.CONECTADO
            } else {
                ShizukuState.SEM_PERMISSAO
            }
        } catch (e: Throwable) {
            ShizukuState.INATIVO
        }
    }

    /** Devolve uma mensagem de erro, ou null se o pedido foi feito (ou não era necessário). */
    fun pedirPermissao(): String? {
        return try {
            if (estado() != ShizukuState.SEM_PERMISSAO) {
                null
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                "Permissão negada. Libere o app dentro do Shizuku."
            } else {
                Shizuku.requestPermission(REQUEST_CODE)
                null
            }
        } catch (e: Throwable) {
            "Não foi possível pedir a permissão"
        }
    }

    /** Roda um comando de shell com a permissão do Shizuku. Nunca lança exceção (exceto cancelamento). */
    suspend fun executar(comando: String, timeoutMs: Long = 60_000L): Resultado =
        withContext(Dispatchers.IO) {
            if (estado() != ShizukuState.CONECTADO) {
                return@withContext Resultado(false, "Shizuku não está conectado")
            }
            try {
                // stderr junto do stdout evita travar por buffer cheio
                val processo = novoProcesso(arrayOf("sh", "-c", "($comando) 2>&1"))
                val estourou = AtomicBoolean(false)
                // Vigia: se passar do tempo, encerra o processo para liberar a leitura
                val vigia = launch {
                    delay(timeoutMs)
                    estourou.set(true)
                    processo.destroy()
                }
                val texto: String = try {
                    processo.inputStream.bufferedReader().use { it.readText() }
                } finally {
                    vigia.cancel()
                    if (processo.isAlive) processo.destroy()
                }
                val codigo = processo.waitFor()
                val saida = texto.trim().take(LIMITE_SAIDA)
                if (estourou.get()) {
                    Resultado(false, "Tempo esgotado (${timeoutMs / 1000}s)")
                } else if (codigo == 0) {
                    Resultado(true, saida)
                } else {
                    Resultado(false, saida.ifBlank { "Código de saída $codigo" })
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Resultado(false, e.cause?.message ?: e.message ?: "Erro desconhecido")
            }
        }

    // Shizuku.newProcess é privado desde a 13.x; a reflexão funciona, mas o caminho
    // oficial é um UserService (AIDL). Dá para migrar depois sem mexer no resto do app.
    private fun novoProcesso(cmd: Array<String>): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java,
        )
        m.isAccessible = true
        return m.invoke(null, cmd, null, null) as Process
    }
}
