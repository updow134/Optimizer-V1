package com.example.optimizer.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun pct(v: Float): String = "${(v * 100f).toInt()}%"

@Composable
fun MonitorScreen(
    historico: List<Amostra>,
    conectado: Boolean,
    modifier: Modifier = Modifier,
) {
    val atual: Amostra? = historico.lastOrNull()
    Column(
        modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        if (!conectado) {
            Text(
                "Conecte o Shizuku para ver os dados em tempo real.",
                color = Neon.Rosa,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Medidor(
                valor = atual?.cpuTotal ?: 0f,
                titulo = "CPU",
                detalhe = "${atual?.nucleos?.size ?: 0} núcleos",
                cor = Neon.Ciano,
                modifier = Modifier.weight(1f),
            )
            Medidor(
                valor = atual?.ramPct ?: 0f,
                titulo = "RAM",
                detalhe = if (atual != null) "${atual.ramUsadaMb}/${atual.ramTotalMb} MB" else "--",
                cor = Neon.Violeta,
                modifier = Modifier.weight(1f),
            )
        }
        PainelGrafico(
            titulo = "CPU · 60s",
            valores = historico.map { it.cpuTotal },
            cor = Neon.Ciano,
            atual = if (atual != null) pct(atual.cpuTotal) else "--",
        )
        PainelGrafico(
            titulo = "RAM · 60s",
            valores = historico.map { it.ramPct },
            cor = Neon.Violeta,
            atual = if (atual != null) pct(atual.ramPct) else "--",
        )
        PainelNucleos(atual?.nucleos ?: emptyList())
        PainelDetalhes(atual)
    }
}

@Composable
fun Medidor(
    valor: Float,
    titulo: String,
    detalhe: String,
    cor: Color,
    modifier: Modifier = Modifier,
) {
    val animado by animateFloatAsState(
        targetValue = valor.coerceIn(0f, 1f),
        animationSpec = tween(700),
        label = "medidor",
    )
    Column(
        modifier.painelTech(cor).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().padding(8.dp)) {
                val espessura = size.minDimension * 0.10f
                val lado = size.minDimension - espessura
                val tamanho = Size(lado, lado)
                val topo = Offset(espessura / 2f, espessura / 2f)
                val varredura = 270f * animado
                drawArc(
                    Color.White.copy(alpha = 0.08f), 135f, 270f, false, topo, tamanho,
                    style = Stroke(width = espessura, cap = StrokeCap.Round),
                )
                drawArc(
                    cor.copy(alpha = 0.25f), 135f, varredura, false, topo, tamanho,
                    style = Stroke(width = espessura * 1.8f, cap = StrokeCap.Round),
                )
                drawArc(
                    cor, 135f, varredura, false, topo, tamanho,
                    style = Stroke(width = espessura, cap = StrokeCap.Round),
                )
            }
            Text(
                pct(animado),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = cor,
            )
        }
        Text(titulo, fontWeight = FontWeight.Bold, letterSpacing = 3.sp, color = cor)
        Text(
            detalhe,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun PainelGrafico(titulo: String, valores: List<Float>, cor: Color, atual: String) {
    Column(
        Modifier.fillMaxWidth().painelTech(cor).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(titulo, style = MaterialTheme.typography.labelMedium, letterSpacing = 2.sp, color = cor)
            Text(atual, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        }
        GraficoLinha(valores, cor, Modifier.fillMaxWidth().height(110.dp))
    }
}

@Composable
fun GraficoLinha(valores: List<Float>, cor: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val largura = size.width
        val altura = size.height
        for (i in 0..4) {
            val y = altura * i / 4f
            drawLine(
                Color.White.copy(alpha = 0.06f),
                Offset(0f, y),
                Offset(largura, y),
                strokeWidth = 1f,
            )
        }
        if (valores.size < 2) return@Canvas
        val passo = largura / (MAX_AMOSTRAS - 1).toFloat()
        val xInicio = largura - passo * (valores.size - 1).toFloat()
        val linha = Path()
        valores.forEachIndexed { i, v ->
            val x = xInicio + passo * i.toFloat()
            val y = altura - v.coerceIn(0f, 1f) * altura
            if (i == 0) linha.moveTo(x, y) else linha.lineTo(x, y)
        }
        val area = Path()
        area.addPath(linha)
        area.lineTo(largura, altura)
        area.lineTo(xInicio, altura)
        area.close()
        drawPath(area, Brush.verticalGradient(listOf(cor.copy(alpha = 0.35f), Color.Transparent)))
        drawPath(
            linha,
            cor.copy(alpha = 0.25f),
            style = Stroke(width = 10f, cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
        drawPath(
            linha,
            cor,
            style = Stroke(width = 3f, cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
    }
}

@Composable
fun PainelNucleos(valores: List<Float>) {
    Column(
        Modifier.fillMaxWidth().painelTech(Neon.Verde).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            "NÚCLEOS",
            style = MaterialTheme.typography.labelMedium,
            letterSpacing = 2.sp,
            color = Neon.Verde,
        )
        if (valores.isEmpty()) {
            Text("Aguardando dados...", style = MaterialTheme.typography.bodySmall)
        } else {
            BarrasNucleos(valores, Neon.Verde, Modifier.fillMaxWidth().height(90.dp))
        }
    }
}

@Composable
fun BarrasNucleos(valores: List<Float>, cor: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val n = valores.size
        if (n == 0) return@Canvas
        val espaco = 8f
        val largura = (size.width - espaco * (n - 1).toFloat()) / n.toFloat()
        val canto = CornerRadius(6f, 6f)
        valores.forEachIndexed { i, v ->
            val x = i.toFloat() * (largura + espaco)
            drawRoundRect(
                Color.White.copy(alpha = 0.07f),
                Offset(x, 0f),
                Size(largura, size.height),
                canto,
            )
            val alt = size.height * v.coerceIn(0f, 1f)
            drawRoundRect(cor, Offset(x, size.height - alt), Size(largura, alt), canto)
        }
    }
}

@Composable
fun PainelDetalhes(a: Amostra?) {
    Column(
        Modifier.fillMaxWidth().painelTech(Neon.Ambar).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(
            "MEMÓRIA",
            style = MaterialTheme.typography.labelMedium,
            letterSpacing = 2.sp,
            color = Neon.Ambar,
        )
        if (a == null) {
            Text("Aguardando dados...", style = MaterialTheme.typography.bodySmall)
        } else {
            Text("RAM: ${a.ramUsadaMb} de ${a.ramTotalMb} MB", fontFamily = FontFamily.Monospace)
            Text("Swap: ${a.swapUsadaMb} de ${a.swapTotalMb} MB", fontFamily = FontFamily.Monospace)
            Text("CPU: ${pct(a.cpuTotal)} em ${a.nucleos.size} núcleos", fontFamily = FontFamily.Monospace)
            Text(
                "Calor: ${a.tempC?.let { "%.1f°".format(it) } ?: "sem leitura"}",
                fontFamily = FontFamily.Monospace,
            )
            Text(
                "Bateria: ${a.bateriaPct?.let { "$it%" } ?: "sem leitura"}",
                fontFamily = FontFamily.Monospace,
            )
            Text(
                "GPU: ${a.gpuPct?.let { pct(it) } ?: "não disponível neste aparelho"}",
                fontFamily = FontFamily.Monospace,
            )
            Text(
                if (a.freqMhz.isEmpty()) "Frequência: não disponível"
                else "Frequência: ${a.freqMhz.joinToString(" · ") { "$it MHz" }}",
                fontFamily = FontFamily.Monospace,
            )
        }
    }
}
