package com.example.optimizer.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.optimizer.R

@Composable
fun HubScreen(
    vm: OptimizerViewModel,
    conectado: Boolean,
    modifier: Modifier = Modifier,
) {
    val foco by vm.foco.collectAsStateWithLifecycle()
    val partida by vm.partida.collectAsStateWithLifecycle()
    val pacto by vm.pacto.collectAsStateWithLifecycle()
    val relato by vm.relato.collectAsStateWithLifecycle()
    var genero by rememberSaveable { mutableStateOf(GENEROS_HUB[0]) }
    var nome by rememberSaveable { mutableStateOf("") }
    val scroll = rememberScrollState()

    Column(
        modifier
            .verticalScroll(scroll)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(R.drawable.lucy),
                contentDescription = "Lucy",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape),
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Lucy", fontWeight = FontWeight.SemiBold, color = Neon.Rosa)
                Text(
                    "Eu leio o jogo aberto e fecho o pacto. No celular isso mexe de verdade.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        Column(Modifier.painelTech(Neon.Rosa).padding(14.dp)) {
            Text("Foco da tela", color = Neon.Ciano, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Text(
                foco?.pacote ?: "Nenhum jogo lido ainda.",
                color = MaterialTheme.colorScheme.onSurface,
            )
            if (foco != null) {
                Text(
                    if (foco!!.conhecido) "Reconhecido: ${foco!!.nome} · ${foco!!.genero}"
                    else "Pacote novo. Escolhe o tipo e eu monto o pacto.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = vm::lerFoco,
                enabled = conectado && !partida.ativa,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Ler o jogo aberto") }
        }

        if (!conectado) {
            Text(
                "O Shizuku precisa estar ativo. Sem ele a Lucy não mexe no Hz nem no fundo.",
                color = Neon.Ambar,
            )
        }

        pacto?.let { p ->
            Column(Modifier.painelTech().padding(14.dp)) {
                Text(p.tese, color = MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.height(8.dp))
                Text(
                    "${p.hz} Hz · tela ${(p.res * 100).toInt()}% · animação ${p.animator}",
                    color = Neon.Ciano,
                    fontWeight = FontWeight.Medium,
                )
                Text(
                    "Driver ${nomeDriver(p.driver)}. ${detalheDriver(p.driver)}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                p.quedas.forEach { q ->
                    Text(q.nome, color = Neon.Rosa, fontWeight = FontWeight.Medium)
                    Text(q.corta, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                }
                if (!partida.ativa) {
                    Button(
                        onClick = vm::entrarPartida,
                        enabled = conectado,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Entrar na partida") }
                }
            }
        }

        if (partida.ativa) {
            Column(Modifier.painelTech(Neon.Ambar).padding(14.dp)) {
                Text("Em partida · ${partida.nome}", fontWeight = FontWeight.SemiBold)
                Text(
                    "${partida.hz} Hz · driver ${nomeDriver(partida.driver)} · calor ${partida.temp?.let { "%.1f°".format(it) } ?: "—"} · ping ${partida.ping?.let { "${it} ms" } ?: "—"}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (partida.nota.isNotBlank()) {
                    Text(partida.nota, color = Neon.Ambar)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = vm::encerrarPartida, modifier = Modifier.fillMaxWidth()) {
                    Text("Encerrar e restaurar")
                }
            }
        }

        if (!partida.ativa) {
            relato?.let { r ->
                Column(Modifier.painelTech(Neon.Rosa).padding(14.dp)) {
                    Text("Relato da ${r.jogo}", fontWeight = FontWeight.SemiBold, color = Neon.Rosa)
                    Spacer(Modifier.height(6.dp))
                    Text(r.frase)
                    Text(
                        "Calor ${r.pico.toInt()}° · cortes ${r.cortes} · ping ${if (r.ping == 0) "—" else "${r.ping} ms"} · picos ${r.picosPing}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    TextButton(onClick = vm::dispensarRelato) { Text("Dispensar") }
                }
            }
        }

        if (foco != null && foco?.conhecido == false && !partida.ativa) {
            Column(Modifier.painelTech().padding(14.dp)) {
                Text("Colocar no hub", fontWeight = FontWeight.Medium)
                androidx.compose.material3.OutlinedTextField(
                    value = nome,
                    onValueChange = { if (it.length <= 32) nome = it },
                    label = { Text("Nome do jogo") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                )
                Row(
                    Modifier
                        .padding(top = 8.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    GENEROS_HUB.forEach { g ->
                        if (g == genero) {
                            Button(onClick = { genero = g }) { Text(g) }
                        } else {
                            TextButton(onClick = { genero = g }) { Text(g) }
                        }
                    }
                }
                Button(
                    onClick = {
                        vm.definirJogo(nome, genero)
                        nome = ""
                    },
                    enabled = nome.trim().length >= 2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                ) { Text("Montar pacto") }
            }
        }
    }
}
