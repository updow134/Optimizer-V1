package com.example.optimizer.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.optimizer.R

@Composable
fun HubScreen(
    vm: OptimizerViewModel,
    conectado: Boolean,
    modifier: Modifier = Modifier,
) {
    val contexto = LocalContext.current
    val foco by vm.foco.collectAsStateWithLifecycle()
    val partida by vm.partida.collectAsStateWithLifecycle()
    val pacto by vm.pacto.collectAsStateWithLifecycle()
    val relato by vm.relato.collectAsStateWithLifecycle()
    var bolha by rememberSaveable { mutableStateOf(LucyBolhaService.ligada) }
    var verTermos by rememberSaveable { mutableStateOf(false) }
    val inicial = remember { LucyPrefs.ler(contexto) }
    var rascunho by remember { mutableStateOf(inicial) }
    var limpeza by remember { mutableStateOf(inicial.limpeza) }
    var branco by remember { mutableStateOf(inicial.branco) }
    var busca by rememberSaveable { mutableStateOf("") }
    var apps by remember { mutableStateOf<List<AppDaLista>>(emptyList()) }
    val pedirNotificacao = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { concedida ->
        if (concedida) {
            vm.ligarBolha()
            bolha = true
        }
    }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.Default) { listarApps(contexto.packageManager, contexto.packageName) }
    }

    fun gravarMemoria(novaLimpeza: Boolean, novaLista: Set<String>) {
        val visual = LucyPrefs.ler(contexto)
        LucyPrefs.gravar(contexto, visual.copy(limpeza = novaLimpeza, branco = novaLista))
        limpeza = novaLimpeza
        branco = novaLista
    }

    fun ligar() {
        if (!Settings.canDrawOverlays(contexto)) {
            val uri = Uri.parse("package:${contexto.packageName}")
            contexto.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, uri))
            return
        }
        if (Build.VERSION.SDK_INT >= 33) {
            pedirNotificacao.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            vm.ligarBolha()
            bolha = true
        }
    }

    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(R.drawable.lucy),
                contentDescription = "Lucy",
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(56.dp).clip(CircleShape),
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Hub do jogo", fontWeight = FontWeight.SemiBold, color = Neon.Rosa)
                Text(
                    "Driver, Hz, tela e a bolha ficam aqui. Ela continua lendo com o jogo aberto.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        Column(Modifier.painelTech(Neon.Rosa).padding(14.dp)) {
            Text("Bolha da Lucy", color = Neon.Rosa, fontWeight = FontWeight.Medium)
            Text(
                if (bolha && vm.podeBolha()) "Ligada. Arraste o rosto. Toque para ver o calor e trocar o driver."
                else "Desligada. Sem ela, o app não te acompanha dentro da partida.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            if (bolha && vm.podeBolha()) {
                OutlinedButton(onClick = { vm.desligarBolha(); bolha = false }, modifier = Modifier.fillMaxWidth()) {
                    Text("Desligar a bolha")
                }
            } else {
                Button(onClick = { ligar() }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (vm.podeBolha()) "Ligar a bolha" else "Permitir a bolha sobre o jogo")
                }
            }
        }

        Column(Modifier.painelTech().padding(14.dp)) {
            Text("Prévia da bolha", fontWeight = FontWeight.Medium)
            Text(
                "Muda aqui. A bolha só recebe quando você aplica.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            PreviaBolha(rascunho)
            Text("Tamanho", color = Neon.Ciano)
            LinhaOpcoes(listOf("0" to "Pequena", "1" to "Média", "2" to "Grande"), rascunho.tamanho.toString()) {
                rascunho = rascunho.copy(tamanho = it.toInt())
            }
            Text("Opacidade", color = Neon.Ciano)
            LinhaOpcoes(listOf("0" to "Clara", "1" to "Normal", "2" to "Forte"), rascunho.opacidade.toString()) {
                rascunho = rascunho.copy(opacidade = it.toInt())
            }
            Text("O que aparece", color = Neon.Ciano)
            LinhaMarcas(
                listOf(
                    "nome" to "Jogo",
                    "temp" to "Calor",
                    "hz" to "Hz",
                    "driver" to "Driver",
                    "ping" to "Ping",
                    "frames" to "Frames",
                ),
                setOfNotNull(
                    "nome".takeIf { rascunho.nome },
                    "temp".takeIf { rascunho.temp },
                    "hz".takeIf { rascunho.hz },
                    "driver".takeIf { rascunho.driver },
                    "ping".takeIf { rascunho.ping },
                    "frames".takeIf { rascunho.frames },
                ),
            ) { chave ->
                rascunho = when (chave) {
                    "nome" -> rascunho.copy(nome = !rascunho.nome)
                    "temp" -> rascunho.copy(temp = !rascunho.temp)
                    "hz" -> rascunho.copy(hz = !rascunho.hz)
                    "driver" -> rascunho.copy(driver = !rascunho.driver)
                    "ping" -> rascunho.copy(ping = !rascunho.ping)
                    else -> rascunho.copy(frames = !rascunho.frames)
                }
            }
            Button(
                onClick = {
                    val memoria = LucyPrefs.ler(contexto)
                    LucyPrefs.gravar(contexto, rascunho.copy(limpeza = memoria.limpeza, branco = memoria.branco))
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Aplicar na bolha") }
        }

        Column(Modifier.painelTech().padding(14.dp)) {
            Text("Jogo na frente", color = Neon.Ciano, fontWeight = FontWeight.Medium)
            Text(foco?.pacote ?: "Nada lido ainda.", color = MaterialTheme.colorScheme.onSurface)
            if (foco != null) {
                Text(
                    if (foco!!.conhecido) "${foco!!.nome} · ${foco!!.genero}"
                    else "Pacote novo. Dá um nome e o tipo aqui embaixo.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = vm::lerFoco,
                enabled = conectado && !partida.ativa,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Ler agora") }
        }

        if (!conectado) {
            Text("O Shizuku precisa estar ativo. Sem ele nada disso chega no sistema.", color = Neon.Ambar)
        }

        pacto?.let { p ->
            Column(Modifier.painelTech().padding(14.dp)) {
                Text("Ajustes deste jogo", fontWeight = FontWeight.Medium)
                Text(p.tese, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Text("Hz", color = Neon.Ciano)
                LinhaOpcoes(
                    listOf("60" to "60", "90" to "90", "120" to "120"),
                    p.hz.toString(),
                ) { vm.definirHz(it.toInt()) }
                Text("Driver gráfico", color = Neon.Ciano)
                Text(detalheDriver(p.driver), color = MaterialTheme.colorScheme.onSurfaceVariant)
                LinhaOpcoes(
                    listOf("0" to "Leve", "1" to "Estável", "2" to "Nítido"),
                    p.driver.toString(),
                ) { vm.definirDriver(it.toInt()) }
                Text("Animação", color = Neon.Ciano)
                LinhaOpcoes(
                    listOf("0" to "0", "0.5" to "0,5", "1" to "1"),
                    p.animator,
                ) { vm.definirAnimator(it) }
                Text(
                    "Tela ${(p.res * 100).toInt()}%. O governador desce isso se passar de 42°.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                if (p.quarentena) {
                    Button(onClick = { vm.definirQuarentena(false) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Fundo travado — soltar")
                    }
                } else {
                    OutlinedButton(onClick = { vm.definirQuarentena(true) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Travar fundo, menos o Discord")
                    }
                }
                if (!partida.ativa) {
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = vm::entrarPartida,
                        enabled = conectado,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Entrar na partida") }
                }
            }
        }

        if (partida.ativa) {
            Column(Modifier.painelTech(Neon.Ambar).padding(14.dp)) {
                Text("Dentro de ${partida.nome}", fontWeight = FontWeight.SemiBold)
                Text(
                    "${partida.hz} Hz · ${nomeDriver(partida.driver)} · ${partida.temp?.let { "%.1f°".format(it) } ?: "—"} · ping ${partida.ping?.let { "$it ms" } ?: "—"}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (partida.nota.isNotBlank()) Text(partida.nota, color = Neon.Ambar)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = vm::encerrarPartida, modifier = Modifier.fillMaxWidth()) {
                    Text("Encerrar e restaurar")
                }
            }
        }

        if (!partida.ativa) {
            relato?.let { r ->
                Column(Modifier.painelTech(Neon.Rosa).padding(14.dp)) {
                    Text("Relato da ${r.jogo}", fontWeight = FontWeight.SemiBold, color = Neon.Rosa)
                    Text(r.frase)
                    TextButton(onClick = vm::dispensarRelato) { Text("Dispensar") }
                }
            }
        }

        if (foco != null && foco?.conhecido == false && !partida.ativa) {
            Text(
                "Esse pacote ainda não está no hub. Adicione pela lista abaixo, sem preencher ficha.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        Column(Modifier.painelTech().padding(14.dp)) {
            Text("Memória", fontWeight = FontWeight.Medium)
            Text(
                "Em segundo plano o app encerra processo que não está na frente e não está na lista branca. O jogo aberto nunca entra.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            if (limpeza) {
                Button(onClick = { gravarMemoria(false, branco) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Limpeza automática ligada")
                }
            } else {
                OutlinedButton(onClick = { gravarMemoria(true, branco) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Limpeza automática desligada")
                }
            }
        }

        Column(Modifier.painelTech().padding(14.dp)) {
            Text("Apps", fontWeight = FontWeight.Medium)
            Text(
                "Toque em Usar para colocar no hub. Toque em Proteger para a limpeza ignorar.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                value = busca,
                onValueChange = { busca = it.take(40) },
                label = { Text("Buscar") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
            val filtro = busca.trim().lowercase()
            val visiveis = apps.filter {
                filtro.isBlank() || it.nome.lowercase().contains(filtro) || it.pacote.lowercase().contains(filtro)
            }.take(20)
            visiveis.forEach { app ->
                    val protegido = app.pacote in branco
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(app.nome, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                app.pacote,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        TextButton(onClick = { vm.adicionarPacote(app.pacote, app.nome) }) { Text("Usar") }
                        TextButton(onClick = {
                            val nova = if (protegido) branco - app.pacote else branco + app.pacote
                            gravarMemoria(limpeza, nova)
                        }) { Text(if (protegido) "Livre" else "Proteger") }
                    }
            }
            if (branco.isNotEmpty()) {
                Text(
                    "Protegidos: ${branco.size}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        TextButton(onClick = { verTermos = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Termos de serviço e responsabilidade")
        }
        if (verTermos) {
            Column(Modifier.painelTech().padding(14.dp)) {
                Text(TEXTO_TERMOS, style = MaterialTheme.typography.bodyMedium)
                TextButton(onClick = { verTermos = false }) { Text("Fechar") }
            }
        }
    }
}

private data class AppDaLista(val pacote: String, val nome: String)

private fun listarApps(pm: PackageManager, proprio: String): List<AppDaLista> {
    val consulta = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(consulta, 0).mapNotNull { info ->
        val pacote = info.activityInfo?.packageName ?: return@mapNotNull null
        if (pacote == proprio || !pacoteValido(pacote)) return@mapNotNull null
        val nome = info.loadLabel(pm)?.toString()?.trim().orEmpty().ifBlank { pacote.substringAfterLast('.') }
        AppDaLista(pacote, nome.take(40))
    }.distinctBy { it.pacote }.sortedBy { it.nome.lowercase() }
}

@Composable
private fun LinhaMarcas(
    opcoes: List<Pair<String, String>>,
    marcados: Set<String>,
    aoToque: (String) -> Unit,
) {
    Row(
        Modifier.padding(vertical = 6.dp).horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        opcoes.forEach { (valor, rotulo) ->
            if (valor in marcados) Button(onClick = { aoToque(valor) }) { Text(rotulo) }
            else OutlinedButton(onClick = { aoToque(valor) }) { Text(rotulo) }
        }
    }
}

@Composable
private fun PreviaBolha(a: AparenciaBolha) {
    val lado = listOf(36, 46, 58)[a.tamanho]
    Row(
        Modifier.alpha(listOf(0.55f, 0.82f, 1f)[a.opacidade]).padding(vertical = 8.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Image(
            painter = painterResource(R.drawable.lucy),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(lado.dp).clip(CircleShape),
        )
        Column(Modifier.padding(start = 8.dp)) {
            if (a.nome) Text("Free Fire", fontWeight = FontWeight.Medium, maxLines = 1)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (a.temp) TextoChip("37°")
                if (a.hz) TextoChip("90 Hz")
                if (a.driver) TextoChip("Estável")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (a.ping) TextoChip("41 ms")
                if (a.frames) TextoChip("2% frames")
            }
        }
    }
}

@Composable
private fun TextoChip(texto: String) {
    Text(
        texto,
        maxLines = 1,
        modifier = Modifier
            .padding(top = 4.dp)
            .painelTech()
            .padding(horizontal = 8.dp, vertical = 4.dp),
    )
}

@Composable
private fun LinhaOpcoes(opcoes: List<Pair<String, String>>, atual: String, aoEscolher: (String) -> Unit) {
    Row(
        Modifier.padding(vertical = 6.dp).horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        opcoes.forEach { (valor, rotulo) ->
            if (valor == atual) Button(onClick = { aoEscolher(valor) }) { Text(rotulo) }
            else OutlinedButton(onClick = { aoEscolher(valor) }) { Text(rotulo) }
        }
    }
}
