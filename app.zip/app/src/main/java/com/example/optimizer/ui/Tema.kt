package com.example.optimizer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/** Paleta neon do app. */
object Neon {
    val Ciano: Color = Color(0xFF00E5FF)
    val Violeta: Color = Color(0xFFB388FF)
    val Verde: Color = Color(0xFF69F0AE)
    val Rosa: Color = Color(0xFFFF4081)
    val Ambar: Color = Color(0xFFFFB74D)
    val Fundo: Color = Color(0xFF05070D)
    val Superficie: Color = Color(0xFF0D1424)
    val Borda: Color = Color(0xFF1C2B4A)
}

private val EsquemaTech = darkColorScheme(
    primary = Neon.Ciano,
    onPrimary = Color(0xFF00212A),
    primaryContainer = Color(0xFF0A3A44),
    onPrimaryContainer = Color(0xFFB8F4FF),
    secondary = Neon.Violeta,
    secondaryContainer = Color(0xFF0A3A44),
    onSecondaryContainer = Color(0xFFB8F4FF),
    tertiary = Neon.Verde,
    background = Neon.Fundo,
    onBackground = Color(0xFFE6EEF9),
    surface = Neon.Superficie,
    onSurface = Color(0xFFE6EEF9),
    surfaceVariant = Color(0xFF131D33),
    onSurfaceVariant = Color(0xFF9FB0CC),
    error = Neon.Rosa,
    errorContainer = Color(0xFF4A1226),
    onErrorContainer = Color(0xFFFFD9E3),
    outline = Neon.Borda,
)

@Composable
fun TemaOptimizer(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = EsquemaTech, content = content)
}

/** Painel "vidro escuro" com borda em degradê neon. */
fun Modifier.painelTech(
    cor: Color = Neon.Ciano,
    forma: Shape = RoundedCornerShape(18.dp),
): Modifier = this
    .clip(forma)
    .background(Brush.linearGradient(listOf(Neon.Superficie, Color(0xFF101A30))), forma)
    .border(
        1.dp,
        Brush.linearGradient(listOf(cor.copy(alpha = 0.6f), Neon.Borda, cor.copy(alpha = 0.2f))),
        forma,
    )
