package com.example.optimizer.ui

data class Queda(val nome: String, val corta: String)

data class FocoJogo(
    val pacote: String,
    val nome: String,
    val genero: String,
    val conhecido: Boolean,
)

data class PartidaEstado(
    val ativa: Boolean = false,
    val nome: String = "",
    val hz: Int = 0,
    val temp: Float? = null,
    val nota: String = "",
    val driver: Int = 1,
    val ping: Int? = null,
)


data class Pacto(
    val hz: Int,
    val res: Float,
    val animator: String,
    val driver: Int,
    val quarentena: Boolean,
    val tese: String,
    val quedas: List<Queda>,
)

data class JogoConhecido(val pacote: String, val nome: String, val genero: String)

val JOGOS_CONHECIDOS: List<JogoConhecido> = listOf(
    JogoConhecido("com.dts.freefireth", "Free Fire", "Battle royale"),
    JogoConhecido("com.activision.callofduty.shooter", "COD Mobile", "FPS"),
    JogoConhecido("com.mojang.minecraftpe", "Minecraft", "Mundo aberto"),
    JogoConhecido("com.miHoYo.GenshinImpact", "Genshin", "Mundo aberto"),
    JogoConhecido("com.riotgames.league.wildrift", "Wild Rift", "MOBA"),
    JogoConhecido("com.mobile.legends", "MLBB", "MOBA"),
    JogoConhecido("com.supercell.brawlstars", "Brawl Stars", "Arena"),
    JogoConhecido("com.tencent.ig", "PUBG Mobile", "Battle royale"),
)

val GENEROS_HUB: List<String> = listOf("FPS", "Battle royale", "MOBA", "Mundo aberto", "Arena")

/** Apps de fundo. O segundo valor true vai para restricted. Discord nunca entra. */
val FUNDO_PARTIDA: List<Pair<String, Boolean>> = listOf(
    "com.whatsapp" to true,
    "com.instagram.android" to true,
    "com.zhiliaoapp.musically" to true,
    "com.ss.android.ugc.trill" to true,
    "com.android.chrome" to true,
    "com.google.android.youtube" to true,
    "com.discord" to false,
)

private val PACOTE_OK = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")

fun pacoteValido(p: String): Boolean = PACOTE_OK.matches(p)

fun pactoDe(genero: String, ramGb: Int): Pacto {
    val g = genero.lowercase()
    val entrada = ramGb in 1..4
    val fps = g.contains("fps") || g.contains("battle")
    val moba = g.contains("moba")
    val mundo = g.contains("mundo")
    val arena = g.contains("arena")

    var hz = 90
    var res = 0.85f
    var animator = "0"
    var quarentena = true
    var tese = "90 Hz firme. O pico de 120 costuma despencar no meio da partida."

    if (fps && g.contains("battle")) {
        hz = 90
        res = if (entrada) 0.72f else 0.85f
        animator = "0"
        tese = "Mapa aberto esquenta. Segura 90 Hz e trava o fundo para o frame não cair na queda."
    } else if (fps) {
        hz = 90
        res = if (entrada) 0.72f else 0.80f
        animator = "0"
        tese = "Corta resolução antes do Hz. O recoil fica previsível e o 1% low para de afundar."
    } else if (moba) {
        hz = 120
        res = if (entrada) 0.85f else 1f
        animator = "0"
        tese = "Partida curta. O 120 cabe com o fundo travado. O hitch do teamfight vem do WhatsApp, não da GPU."
    } else if (mundo) {
        hz = 60
        res = if (entrada) 0.70f else 0.78f
        animator = "0.5"
        tese = "Mundo aberto derrete 120. 60 Hz com resolução contida segura a sessão inteira."
    } else if (arena) {
        hz = 60
        res = 1f
        animator = "0.5"
        quarentena = false
        tese = "Jogo leve. Não mata o que está atrás. Só tira animação se o toque atrasar."
    }
    if (entrada && hz > 60) hz = 60
    val driver = driverDe(genero, ramGb)

    val quedas = listOf(
        Queda(
            "Queda de frame",
            if (animator == "0") "Animação em zero. O frame não espera a transição do sistema."
            else "Animação baixa. O jogo leve não precisa de zero.",
        ),
        Queda(
            "Queda térmica",
            if (hz <= 60) "$hz Hz. Não deixa o chip entrar em throttle no meio da sessão."
            else "$hz Hz, não o máximo. O governador corta antes do jogo engasgar.",
        ),
        Queda(
            "Queda de fundo",
            if (quarentena) "Instagram, TikTok e Chrome em restricted. O Discord fica de fora para a call."
            else "Fundo livre. Este jogo não perde frame para notificação.",
        ),
        Queda(
            "Queda de toque",
            if (animator == "0") "Sem escala de animação, o toque chega no mesmo frame do disparo."
            else "Animação em 0,5. Latência aceitável sem deixar o menu seco.",
        ),
    )
    return Pacto(hz, res, animator, driver, quarentena, tese, quedas)
}

fun nomeDriver(n: Int): String = when (n) {
    0 -> "Leve"
    2 -> "Nítido"
    else -> "Estável"
}

fun detalheDriver(n: Int): String = when (n) {
    0 -> "Driver do sistema. Menos carga na GPU."
    2 -> "Game Driver com ANGLE. Mais imagem, mais calor."
    else -> "Game Driver. O frame fica previsível."
}

fun valorAngle(n: Int): String = when (n) {
    0 -> "native"
    2 -> "angle"
    else -> "default"
}

/** 0 leve, 1 estável, 2 nítido. Celular de entrada não passa de estável. */
fun driverDe(genero: String, ramGb: Int): Int {
    val g = genero.lowercase()
    val entrada = ramGb in 1..4
    val n = when {
        g.contains("arena") || g.contains("mundo") -> 0
        g.contains("moba") && !entrada -> 2
        else -> 1
    }
    return if (entrada && n > 1) 1 else n
}

data class Relato(
    val jogo: String,
    val pico: Float,
    val cortes: Int,
    val picosPing: Int,
    val ping: Int,
    val frase: String,
)

fun fecharRelato(jogo: String, pico: Float, cortes: Int, picosPing: Int, ping: Int): Relato {
    val calor = cortes >= 1 || pico >= 42f
    val rede = ping > 0 && picosPing >= 2
    val frase = when {
        calor && rede -> "Duas quedas. O calor veio da carga. O ping veio da rede. Não é o mesmo problema."
        rede -> "A queda foi de ping, não de Hz. O fundo já está travado. Se continuar, é a rede."
        calor -> "Calor a ${pico.toInt()}°. Desci o driver antes de cortar a tela."
        else -> "Partida limpa. Sem queda de calor nem de ping. O pacto segurou."
    }
    return Relato(jogo, pico, cortes, picosPing, ping, frase.take(180))
}

fun partirLista(bruto: String): List<String> {
    val v = bruto.trim()
    if (v.isBlank() || v == "null") return emptyList()
    return v.split(",").map { it.trim() }.filter { it.isNotEmpty() }
}

fun reconhecer(pacote: String): JogoConhecido? =
    JOGOS_CONHECIDOS.firstOrNull { it.pacote == pacote }

private val FOCO_RE = Regex("""([A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z0-9_]+)+)/""")

fun extrairFoco(saida: String): String? {
    val ignorar = listOf(
        "com.android.systemui",
        "com.example.optimizer",
        "com.android.launcher",
        "com.google.android.apps.nexuslauncher",
    )
    return FOCO_RE.findAll(saida)
        .map { it.groupValues[1] }
        .lastOrNull { pacote -> ignorar.none { pacote.startsWith(it) } && pacoteValido(pacote) }
}

private val SIZE_RE = Regex("""(\d{3,5})x(\d{3,5})""")

fun lerTamanho(saida: String): Pair<Int, Int>? {
    val linhas = saida.lines()
    val override = linhas.firstOrNull { it.contains("Override size", ignoreCase = true) }
    val fisica = linhas.firstOrNull { it.contains("Physical size", ignoreCase = true) }
    val alvo = override ?: fisica ?: saida
    val m = SIZE_RE.find(alvo) ?: return null
    val w = m.groupValues[1].toInt()
    val h = m.groupValues[2].toInt()
    if (w < 480 || h < 480) return null
    return w to h
}

fun escalarTela(w: Int, h: Int, fator: Float): String {
    var nw = (w * fator).toInt()
    var nh = (h * fator).toInt()
    if (nw % 2 != 0) nw -= 1
    if (nh % 2 != 0) nh -= 1
    return "${nw}x${nh}"
}
