package com.example.optimizer

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Escopo que sobrevive à tela, sem usar GlobalScope. */
class AppOptimizer : Application() {
    val fundo: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
}
