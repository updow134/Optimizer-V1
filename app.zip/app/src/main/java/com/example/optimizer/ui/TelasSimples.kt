package com.example.optimizer.ui

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle

data class ResNatural(val largura: Int, val altura: Int, val aparelhos: String)

val RESOLUCOES_NATURAIS: List<ResNatural> = listOf(
    ResNatural(1080, 2340, "Galaxy S23, S24 e S25"),
    ResNatural(1440, 3120, "Galaxy S23 Ultra, S24 Ultra e S25 Ultra"),
    ResNatural(1080, 2400, "Pixel 8 e ROG Phone 8"),
    ResNatural(1080, 2424, "Pixel 9"),
    ResNatural(1280, 2856, "Pixel 9 Pro"),
    ResNatural(1344, 2992, "Pixel 8 Pro e Pixel 9 Pro XL"),
    ResNatural(1200, 2670, "Xiaomi 14 e Xiaomi 15"),
    ResNatural(1440, 3200, "Xiaomi 14 Ultra e Xiaomi 15 Ultra"),
    ResNatural(1440, 3168, "OnePlus 12 e OnePlus 13"),
    ResNatural(1080, 2412, "Nothing Phone (2)"),
    ResNatural(1220, 2712, "Poco F6 e Redmi Note 13 Pro"),
    ResNatural(720, 1600, "Modo leve, vários de entrada"),
)

val PERMISSOES_PRONTAS: List<Pair<String, String>> = listOf(
    "Câmera" to "android.permission.CAMERA",
    "Microfone" to "android.permission.RECORD_AUDIO",
    "Localização" to "android.permission.ACCESS_FINE_LOCATION",
    "Contatos" to "android.permission.READ_CONTACTS",
    "Telefone" to "android.permission.READ_PHONE_STATE",
    "Notificações" to "android.permission.POST_NOTIFICATIONS",
    "Fotos" to "android.permission.READ_MEDIA_IMAGES",
)

data class AppListaItem(val pacote: String, val nome: String, val ligado: Boolean)

fun appsParaLista(ctx: Context): List<AppListaItem> {
    val pm = ctx.packageManager
    val flags = PackageManager.MATCH_DISABLED_COMPONENTS
    return pm.getInstalledApplications(flags).mapNotNull { info ->
        val pacote = info.packageName
        if (pacote == ctx.packageName || pacoteProtegido(pacote)) return@mapNotNull null
        val sistema = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        if (sistema && info.enabled) return@mapNotNull null
        val nome = pm.getApplicationLabel(info).toString().ifBlank { pacote.substringAfterLast('.') }
        AppListaItem(pacote, nome, info.enabled)
    }.sortedBy { it.nome.lowercase() }
}

@Composable
fun IconePacote(pacote: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val imagem = remember(pacote) {
        runCatching {
            val d = ctx.packageManager.getApplicationIcon(pacote)
            val px = (40 * ctx.resources.displayMetrics.density).toInt().coerceIn(40, 128)
            val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            d.setBounds(0, 0, px, px)
            d.draw(canvas)
            bmp.asImageBitmap()
        }.getOrNull()
    }
    if (imagem != null) {
        Image(imagem, contentDescription = null, modifier = modifier.clip(RoundedCornerShape(10.dp)))
    } else {
        Box(modifier.clip(RoundedCornerShape(10.dp)).painelTech(), contentAlignment = Alignment.Center) {
            Text(pacote.take(1).uppercase())
        }
    }
}

@Composable
fun PainelCheio(titulo: String, onFechar: () -> Unit, conteudo: @Composable () -> Unit) {
    Dialog(
        onDismissRequest = onFechar,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(10.dp)
                .painelTech()
                .padding(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(titulo, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                TextButton(onClick = onFechar) { Text("Fechar") }
            }
            Box(Modifier.weight(1f)) { conteudo() }
        }
    }
}

@Composable
fun PainelResolucao(onAplicar: (String) -> Unit, onFechar: () -> Unit) {
    PainelCheio("Resolução", onFechar) {
        Text(
            "Cada cartão é a tela nativa de um topo de linha. Ao tocar, a sua muda na hora e volta em 10 segundos.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            RESOLUCOES_NATURAIS.forEach { res ->
                val proporcao = res.largura.toFloat() / res.altura.toFloat()
                Row(
                    Modifier.fillMaxWidth().painelTech().padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier
                            .height(72.dp)
                            .width((72 * proporcao).dp)
                            .painelTech(Neon.Ciano),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("${res.largura}", style = MaterialTheme.typography.labelSmall, maxLines = 1)
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                        Text("${res.largura} × ${res.altura}", fontWeight = FontWeight.Medium)
                        Text(
                            res.aparelhos,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Button(onClick = { onAplicar("${res.largura}x${res.altura}") }) { Text("Testar") }
                }
            }
        }
    }
}

@Composable
fun PainelProcessos(vm: OptimizerViewModel, onFechar: () -> Unit) {
    val processos by vm.processos.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.lerProcessos() }
    PainelCheio("Parar o que está pesado", onFechar) {
        Text(
            "Os mais pesados aparecem primeiro. Parar fecha o app. O jogo e o sistema ficam de fora.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
            if (processos.isEmpty()) {
                Text("Nada pesado agora, ou o Shizuku ainda não leu.")
            }
            processos.forEach { p ->
                val bloqueado = pacoteProtegido(p.pacote)
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconePacote(p.pacote, Modifier.size(40.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                        Text(nomeLocal(p.pacote), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${p.mb} MB",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (bloqueado) {
                        Text("sistema", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Button(onClick = { vm.pararProcesso(p.pacote) }) { Text("Parar") }
                    }
                }
            }
        }
    }
}

@Composable
fun PainelCongelar(vm: OptimizerViewModel, soCongelados: Boolean, onFechar: () -> Unit) {
    val ctx = LocalContext.current
    var busca by remember { mutableStateOf("") }
    var apps by remember { mutableStateOf(appsParaLista(ctx)) }
    var filtro by remember { mutableStateOf(if (soCongelados) "off" else "on") }
    PainelCheio(if (soCongelados) "Descongelar" else "Congelar", onFechar) {
        Text(
            "Congelar tira o app da gaveta sem apagar. Descongelar devolve.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedTextField(
            value = busca,
            onValueChange = { busca = it.take(40) },
            label = { Text("Buscar app") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            if (filtro == "on") Button(onClick = { filtro = "on" }) { Text("Ligados") }
            else OutlinedButton(onClick = { filtro = "on" }) { Text("Ligados") }
            if (filtro == "off") Button(onClick = { filtro = "off" }) { Text("Congelados") }
            else OutlinedButton(onClick = { filtro = "off" }) { Text("Congelados") }
        }
        val q = busca.trim().lowercase()
        val visiveis = apps.filter { item ->
            val casa = (filtro == "on" && item.ligado) || (filtro == "off" && !item.ligado)
            casa && (q.isBlank() || item.nome.lowercase().contains(q) || item.pacote.lowercase().contains(q))
        }.take(40)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            visiveis.forEach { app ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconePacote(app.pacote, Modifier.size(40.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                        Text(app.nome, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (app.ligado) "Aberto na gaveta" else "Congelado",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (app.ligado) {
                        Button(onClick = {
                            vm.congelarPacote(app.pacote, true)
                            apps = apps.map { if (it.pacote == app.pacote) it.copy(ligado = false) else it }
                        }) { Text("Congelar") }
                    } else {
                        OutlinedButton(onClick = {
                            vm.congelarPacote(app.pacote, false)
                            apps = apps.map { if (it.pacote == app.pacote) it.copy(ligado = true) else it }
                        }) { Text("Soltar") }
                    }
                }
            }
        }
    }
}

@Composable
fun PainelPermissoes(vm: OptimizerViewModel, onFechar: () -> Unit) {
    val ctx = LocalContext.current
    var busca by remember { mutableStateOf("") }
    val apps = remember { appsParaLista(ctx).filter { it.ligado } }
    var aberto by remember { mutableStateOf<String?>(null) }
    PainelCheio("Permissões", onFechar) {
        Text(
            "Escolha o app e toque em Permitir ou Tirar. Não precisa digitar o nome da permissão.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedTextField(
            value = busca,
            onValueChange = { busca = it.take(40) },
            label = { Text("Buscar app") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        )
        val q = busca.trim().lowercase()
        val visiveis = apps.filter {
            q.isBlank() || it.nome.lowercase().contains(q) || it.pacote.lowercase().contains(q)
        }.take(30)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            visiveis.forEach { app ->
                Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconePacote(app.pacote, Modifier.size(40.dp))
                        Text(
                            app.nome,
                            modifier = Modifier.weight(1f).padding(horizontal = 10.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        TextButton(onClick = { aberto = if (aberto == app.pacote) null else app.pacote }) {
                            Text(if (aberto == app.pacote) "Fechar" else "Permissões")
                        }
                    }
                    if (aberto == app.pacote) {
                        PERMISSOES_PRONTAS.forEach { (nome, permissao) ->
                            Row(
                                Modifier.fillMaxWidth().padding(start = 50.dp, top = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(nome, modifier = Modifier.weight(1f))
                                TextButton(onClick = { vm.mudarPermissao(app.pacote, permissao, true) }) {
                                    Text("Permitir")
                                }
                                TextButton(onClick = { vm.mudarPermissao(app.pacote, permissao, false) }) {
                                    Text("Tirar")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun nomeLocal(pacote: String): String {
    val ctx = LocalContext.current
    return remember(pacote) {
        runCatching {
            val info = ctx.packageManager.getApplicationInfo(pacote, 0)
            ctx.packageManager.getApplicationLabel(info).toString()
        }.getOrDefault(pacote.substringAfterLast('.'))
    }
}
