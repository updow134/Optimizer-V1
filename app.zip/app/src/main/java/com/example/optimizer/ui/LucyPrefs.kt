package com.example.optimizer.ui

import android.content.Context

data class AparenciaBolha(
    val tamanho: Int,
    val opacidade: Int,
    val nome: Boolean,
    val temp: Boolean,
    val hz: Boolean,
    val driver: Boolean,
    val ping: Boolean,
    val frames: Boolean,
    val limpeza: Boolean,
    val branco: Set<String>,
)

object LucyPrefs {
    const val ARQ = "lucy-bolha"

    val BRANCO_PADRAO: Set<String> = setOf(
        "com.discord",
        "com.whatsapp",
        "com.google.android.apps.messaging",
        "com.google.android.dialer",
        "com.android.dialer",
        "com.samsung.android.dialer",
    )

    fun ler(ctx: Context): AparenciaBolha {
        val p = ctx.getSharedPreferences(ARQ, Context.MODE_PRIVATE)
        val branco = p.getStringSet("branco", null)?.toSet() ?: BRANCO_PADRAO
        return AparenciaBolha(
            tamanho = p.getInt("tamanho", 0).coerceIn(0, 2),
            opacidade = p.getInt("opacidade", 1).coerceIn(0, 2),
            nome = p.getBoolean("info_nome", true),
            temp = p.getBoolean("info_temp", true),
            hz = p.getBoolean("info_hz", true),
            driver = p.getBoolean("info_driver", true),
            ping = p.getBoolean("info_ping", true),
            frames = p.getBoolean("info_frames", true),
            limpeza = p.getBoolean("limpeza", true),
            branco = branco,
        )
    }

    fun gravar(ctx: Context, a: AparenciaBolha) {
        ctx.getSharedPreferences(ARQ, Context.MODE_PRIVATE).edit()
            .putInt("tamanho", a.tamanho.coerceIn(0, 2))
            .putInt("opacidade", a.opacidade.coerceIn(0, 2))
            .putBoolean("info_nome", a.nome)
            .putBoolean("info_temp", a.temp)
            .putBoolean("info_hz", a.hz)
            .putBoolean("info_driver", a.driver)
            .putBoolean("info_ping", a.ping)
            .putBoolean("info_frames", a.frames)
            .putBoolean("limpeza", a.limpeza)
            .putStringSet("branco", a.branco.toHashSet())
            .apply()
    }
}

fun termosAceitos(ctx: Context): Boolean =
    ctx.getSharedPreferences("optimizer-termos", Context.MODE_PRIVATE).getBoolean("aceito", false)

fun aceitarTermos(ctx: Context) {
    ctx.getSharedPreferences("optimizer-termos", Context.MODE_PRIVATE)
        .edit().putBoolean("aceito", true).apply()
}
