package com.example.optimizer.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

val TEXTO_TERMOS: String = """
Termos de serviço e de responsabilidade — Optimizer

Ao usar o Optimizer você aceita o que está escrito aqui. Se não aceitar, não use o app.

O que o app faz
O Optimizer muda ajustes do Android pelo Shizuku: taxa da tela, resolução, animação, driver gráfico e o bucket de apps em segundo plano. Ele mostra uma bolha sobre outros apps e pode encerrar processos em segundo plano para liberar RAM. Nada disso é enviado para um servidor. As escolhas ficam no aparelho.

O que o app não faz
Não mira por você, não puxa a cabeça de inimigo e não lê a memória do jogo. Isso é cheat. O Optimizer não faz e não deve ser usado para isso.

Sua responsabilidade
Você autoriza cada permissão. A bolha sobre outros apps, a notificação permanente e o Shizuku são seus. Mudar driver, Hz ou matar processo pode fechar um app que você queria aberto, esquentar o celular ou fazer um jogo pedir para ser reaberto. A lista branca existe para você proteger o que não pode parar. Se um app importante não estiver nela, a limpeza pode encerrá-lo.

Jogos online
O app não é da Garena, da Tencent, da Riot nem de qualquer publisher. Usar ferramenta externa pode ir contra as regras do jogo. Você assume esse risco. O Optimizer não promete mais FPS nem vitória.

Limite
O app é fornecido como está. Não há garantia de que um ajuste vai funcionar no seu modelo. Em caso de tela estranha, encerre a partida dentro do Optimizer: ele devolve Hz, resolução, animação e as listas de driver que gravou no começo.

Novembro de 2026.
""".trimIndent()

@Composable
fun TermosScreen(aoAceitar: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Antes de usar", color = Neon.Rosa, fontWeight = FontWeight.SemiBold)
        Text(TEXTO_TERMOS, style = MaterialTheme.typography.bodyMedium)
        Button(onClick = aoAceitar, modifier = Modifier.fillMaxWidth()) {
            Text("Aceito os termos")
        }
    }
}
