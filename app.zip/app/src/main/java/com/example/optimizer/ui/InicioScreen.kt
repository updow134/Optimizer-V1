package com.example.optimizer.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import com.example.optimizer.R
import com.example.optimizer.nucleo.Recomendacao
import com.example.optimizer.nucleo.RegistroGuard

private fun textoMb(mb: Int): String {
    if (mb < 1024) return "$mb MB"
    val inteiro = mb / 1024
    val decimal = ((mb % 1024) * 10) / 1024
    return "$inteiro.$decimal GB"
}

private val PERFIS = listOf("Performance", "Balanceado", "Economia", "Personalizado")

fun notaAgora(a: Amostra?): Int? {
    if (a == null) return null
    val cpuLivre = (1f - a.cpuTotal).coerceIn(0f, 1f)
    val ramLivre = (1f - a.ramPct).coerceIn(0f, 1f)
    val calor = when {
        a.tempC == null -> ramLivre
        a.tempC >= 45f -> 0.25f
        a.tempC >= 40f -> 0.6f
        else -> 1f
    }
    return ((cpuLivre * 0.45f + ramLivre * 0.35f + calor * 0.20f) * 100f).toInt().coerceIn(0, 100)
}

fun fraseNota(a: Amostra?, nota: Int?): String {
    if (a == null || nota == null) return "Ainda não li o aparelho. Abra esta tela com o Shizuku ligado."
    val calor = a.tempC?.let { " Calor ${it.toInt()}°." } ?: ""
    return when {
        a.tempC != null && a.tempC >= 42f -> "Calor alto.$calor O jogo deve segurar o Hz."
        a.ramPct >= 0.85f -> "RAM em ${(a.ramPct * 100).toInt()}%. A otimização rápida fecha o que está atrás."
        a.cpuTotal >= 0.8f -> "CPU em ${(a.cpuTotal * 100).toInt()}% agora.$calor"
        else -> "Leitura deste instante: CPU ${(a.cpuTotal * 100).toInt()}%, RAM ${(a.ramPct * 100).toInt()}%.$calor"
    }
}

@Composable
fun InicioScreen(
    historico: List<Amostra>,
    conectado: Boolean,
    perfil: String,
    jogos: List<Pair<String, String>>,
    onPerfil: (String) -> Unit,
    onOtimizar: () -> Unit,
    onFerramenta: (String) -> Unit,
    onGaming: () -> Unit,
    pendentes: List<RegistroGuard>,
    snapPendente: Boolean,
    recomendacoes: List<Recomendacao>,
    onRestaurar: (String) -> Unit,
    onRestaurarTudo: () -> Unit,
    onRestaurarPartida: () -> Unit,
    onAplicarRec: (String) -> Unit,
    onIgnorarRec: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val atual = historico.lastOrNull()
    val nota = notaAgora(atual)
    Column(
        modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painterResource(R.drawable.lucy),
                contentDescription = null,
                modifier = Modifier.size(44.dp).clip(CircleShape),
            )
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Text("OPTIMIZER", fontWeight = FontWeight.Black, color = Neon.Ciano)
                Text("4.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (conectado) Icons.Default.Check else Icons.Default.Warning,
                    contentDescription = null,
                    tint = if (conectado) Neon.Verde else Neon.Ambar,
                )
                Text(
                    if (conectado) "Shizuku ligado" else "Shizuku parado",
                    modifier = Modifier.padding(start = 6.dp),
                    color = if (conectado) Neon.Verde else Neon.Ambar,
                )
            }
        }

        AnelNota(nota)
        Text(fraseNota(atual, nota), color = MaterialTheme.colorScheme.onSurfaceVariant)

        if (snapPendente) {
            Column(Modifier.fillMaxWidth().painelTech(Neon.Ambar).padding(12.dp)) {
                Text("Partida interrompida", fontWeight = FontWeight.Medium, color = Neon.Ambar)
                Text("A tela pode ter ficado no ajuste do jogo. Nada foi desfeito sozinho.")
                Button(onClick = onRestaurarPartida, modifier = Modifier.fillMaxWidth()) {
                    Text("Devolver a tela")
                }
            }
        }
        if (pendentes.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().painelTech(Neon.Ambar).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Optimizer Guard", fontWeight = FontWeight.Medium, color = Neon.Ambar)
                Text("Alterações que ainda dá para desfazer.")
                pendentes.take(4).forEach { item ->
                    Text(item.operacao, fontWeight = FontWeight.Medium)
                    Text("Antes: ${item.original}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = { onRestaurar(item.id) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Restaurar")
                    }
                }
                if (pendentes.size > 1) {
                    Button(onClick = onRestaurarTudo, modifier = Modifier.fillMaxWidth()) { Text("Restaurar todas") }
                }
            }
        }
        if (recomendacoes.isNotEmpty()) {
            Text("Diagnóstico", fontWeight = FontWeight.Medium)
            recomendacoes.forEach { rec ->
                Column(Modifier.fillMaxWidth().painelTech(Neon.Ciano).padding(12.dp)) {
                    Text(rec.problema, fontWeight = FontWeight.Medium)
                    Text(rec.explicacao)
                    Text("Ajuste: ${rec.ajuste}")
                    Text("Benefício: ${rec.beneficio}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Risco: ${rec.risco}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (rec.compativel && rec.id != "shizuku") {
                            Button(onClick = { onAplicarRec(rec.id) }) { Text("Aplicar") }
                        }
                        Button(onClick = { onIgnorarRec(rec.id) }) { Text("Ignorar") }
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MiniDado("CPU", atual?.let { "${(it.cpuTotal * 100).toInt()}%" } ?: "—", Neon.Ciano, Modifier.weight(1f))
            MiniDado(
                "RAM",
                if (atual != null) "${textoMb(atual.ramUsadaMb)} / ${textoMb(atual.ramTotalMb)}" else "—",
                Neon.Violeta,
                Modifier.weight(1f),
            )
            MiniDado("Calor", atual?.tempC?.let { "${it.toInt()}°" } ?: "—", Neon.Ambar, Modifier.weight(1f))
        }

        Button(onClick = onOtimizar, enabled = conectado, modifier = Modifier.fillMaxWidth()) {
            Text("Otimização rápida")
        }
        Text(
            "Fecha apps que ficaram atrás. Não mexe no que está na frente.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Text("Perfil ativo", fontWeight = FontWeight.Medium)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PERFIS.take(2).forEach { nome ->
                Button(
                    onClick = { onPerfil(nome) },
                    modifier = Modifier.weight(1f),
                ) { Text(if (perfil == nome) "● $nome" else nome, maxLines = 1) }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PERFIS.drop(2).forEach { nome ->
                Button(onClick = { onPerfil(nome) }, modifier = Modifier.weight(1f)) {
                    Text(if (perfil == nome) "$nome · agora" else nome, maxLines = 1)
                }
            }
        }

        Text("Acesso rápido", fontWeight = FontWeight.Medium)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Limpar RAM", "Resolução", "Taxa de atualização", "Animações").forEach { nome ->
                Button(onClick = { onFerramenta(nome) }, modifier = Modifier.weight(1f)) {
                    Text(nome.substringBefore(" "), maxLines = 1)
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Jogos recentes", fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Button(onClick = onGaming) { Text("Gaming") }
        }
        if (jogos.isEmpty()) {
            Text(
                "Nenhum ainda. No Gaming, toque em Usar no app do jogo.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            jogos.forEach { (nome, pacote) ->
                Row(
                    Modifier.fillMaxWidth().painelTech().padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconePacote(pacote, Modifier.size(36.dp))
                    Text(nome, modifier = Modifier.padding(start = 10.dp))
                }
            }
        }
    }
}

@Composable
private fun AnelNota(nota: Int?) {
    val alvo = (nota ?: 0) / 100f
    val animado by animateFloatAsState(alvo, tween(700), label = "anel")
    Box(Modifier.fillMaxWidth().aspectRatio(1.6f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(8.dp)) {
            val esp = size.minDimension * 0.08f
            val lado = size.minDimension - esp
            val topo = Offset((size.width - lado) / 2f, esp / 2f)
            val tam = Size(lado, lado)
            drawArc(
                Neon.Ciano.copy(alpha = 0.15f),
                135f, 270f, false, topo, tam,
                style = Stroke(esp, cap = StrokeCap.Round),
            )
            drawArc(
                Neon.Ciano,
                135f, 270f * animado, false, topo, tam,
                style = Stroke(esp, cap = StrokeCap.Round),
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(nota?.let { "$it%" } ?: "—", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text(
                if (nota == null) "sem leitura" else "CPU, RAM e calor",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun MiniDado(titulo: String, valor: String, cor: androidx.compose.ui.graphics.Color, modifier: Modifier) {
    Column(modifier.painelTech(cor).padding(12.dp)) {
        Text(titulo, color = cor, style = MaterialTheme.typography.labelMedium)
        Text(valor, fontWeight = FontWeight.SemiBold)
    }
}
