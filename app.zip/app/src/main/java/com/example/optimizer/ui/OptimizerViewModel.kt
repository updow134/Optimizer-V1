package com.example.optimizer.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

/** Tipos de campo: cada um valida a entrada (e garante que ela é segura para o shell). */
enum class TipoCampo(val dica: String, val regex: Regex) {
    NUMERO("somente números", Regex("^[0-9]{1,5}$")),
    ESCALA("use 0, 0.5, 1, 1.5 ou 2", Regex("^(0|0\\.5|1|1\\.5|2)$")),
    RESOLUCAO("ex: 1080x2400", Regex("^[0-9]{3,5}x[0-9]{3,5}$")),
    PACOTE("ex: com.app.exemplo", Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")),
    PERMISSAO("ex: android.permission.CAMERA", Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")),
    ACAO("grant ou revoke", Regex("^(grant|revoke)$")),
    BUCKET(
        "active, working_set, frequent, rare ou restricted",
        Regex("^(active|working_set|frequent|rare|restricted)$"),
    ),
}

data class Campo(val rotulo: String, val tipo: TipoCampo, val faixa: IntRange? = null)

data class Ferramenta(
    val categoria: String,
    val nome: String,
    val descricao: String,
    val icone: ImageVector,
    val campos: List<Campo> = emptyList(),
    val aviso: String? = null,
    val reverter: String? = null,          // comando de desfazer (contagem de 10s)
    val mostrarSaida: Boolean = false,
    val protegerPacotes: Boolean = false,  // bloqueia apps essenciais do sistema
    val timeoutSeg: Int = 60,
    val montar: (List<String>) -> String,  // valores já validados
)

private val PACOTES_PROTEGIDOS: Set<String> = setOf(
    "com.android.systemui", "com.android.phone", "com.android.settings",
    "com.android.launcher3", "com.google.android.gms", "com.google.android.gsf",
    "com.android.vending", "moe.shizuku.privileged.api", "com.example.optimizer",
)

private fun pacoteProtegido(p: String): Boolean =
    p in PACOTES_PROTEGIDOS ||
        p.startsWith("com.android.providers.") ||
        p.startsWith("com.android.inputmethod")

/** Devolve a mensagem de erro, ou null se tudo estiver válido. */
fun validarCampos(f: Ferramenta, valores: List<String>): String? {
    if (valores.size != f.campos.size) return "Preencha todos os campos"
    for (i in f.campos.indices) {
        val campo = f.campos[i]
        val v = valores[i]
        if (!campo.tipo.regex.matches(v)) return "${campo.rotulo}: ${campo.tipo.dica}"
        val faixa = campo.faixa
        if (faixa != null) {
            val n = v.toIntOrNull()
            if (n == null || n !in faixa) {
                return "${campo.rotulo}: use de ${faixa.first} a ${faixa.last}"
            }
        }
        if (f.protegerPacotes && campo.tipo == TipoCampo.PACOTE && pacoteProtegido(v)) {
            return "Pacote protegido: mexer nele pode quebrar o sistema"
        }
    }
    return null
}

val FERRAMENTAS: List<Ferramenta> = listOf(
    // ---- Rápidas ----
    Ferramenta("Rápidas", "Limpar cache", "Libera espaço dos apps", Icons.Default.Delete,
        timeoutSeg = 120) {
        "pm trim-caches 999G"
    },
    Ferramenta("Rápidas", "Limpar RAM", "Encerra apps em 2º plano", Icons.Default.Close,
        timeoutSeg = 30) {
        "am kill-all"
    },
    Ferramenta("Rápidas", "Compilar ART", "Modo speed nos apps", Icons.Default.Build,
        aviso = "Pode levar vários minutos e esquentar o aparelho. Mantenha o app aberto.",
        timeoutSeg = 900) {
        "cmd package compile -m speed -a"
    },
    Ferramenta("Rápidas", "Animações", "Escala 0.5x / 0x", Icons.Default.PlayArrow,
        campos = listOf(Campo("Escala", TipoCampo.ESCALA))) { v ->
        "settings put global window_animation_scale ${v[0]}; " +
            "settings put global transition_animation_scale ${v[0]}; " +
            "settings put global animator_duration_scale ${v[0]}"
    },
    Ferramenta("Rápidas", "Congelar app", "Desativa um app", Icons.Default.Lock,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE)), protegerPacotes = true) { v ->
        "pm disable-user --user 0 ${v[0]}"
    },

    // ---- Tela ----
    Ferramenta("Tela", "DPI", "Densidade da tela", Icons.Default.Edit,
        campos = listOf(Campo("DPI", TipoCampo.NUMERO, 120..800)),
        aviso = "Reverte sozinho em 10s se você não confirmar.",
        reverter = "wm density reset") { v ->
        "wm density ${v[0]}"
    },
    Ferramenta("Tela", "Resolução", "Reduz para ganhar fluidez", Icons.Default.Search,
        campos = listOf(Campo("Resolução", TipoCampo.RESOLUCAO)),
        aviso = "Reverte sozinho em 10s se você não confirmar.",
        reverter = "wm size reset") { v ->
        "wm size ${v[0]}"
    },
    Ferramenta("Tela", "Taxa de atualização", "60 / 90 / 120 Hz", Icons.Default.Refresh,
        campos = listOf(Campo("Hz", TipoCampo.NUMERO, 0..240)),
        aviso = "Use 0 para restaurar o padrão do sistema.") { v ->
        if (v[0] == "0") {
            "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
        } else {
            "settings put system min_refresh_rate ${v[0]}; settings put system peak_refresh_rate ${v[0]}"
        }
    },

    // ---- Apps ----
    Ferramenta("Apps", "Forçar parada", "Encerra um app agora", Icons.Default.Close,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE)), protegerPacotes = true) { v ->
        "am force-stop ${v[0]}"
    },
    Ferramenta("Apps", "Descongelar app", "Reativa um app", Icons.Default.Lock,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE))) { v ->
        "pm enable ${v[0]}"
    },
    Ferramenta("Apps", "Permissões", "Conceder ou revogar", Icons.Default.Person,
        campos = listOf(
            Campo("Pacote", TipoCampo.PACOTE),
            Campo("Permissão", TipoCampo.PERMISSAO),
            Campo("Ação", TipoCampo.ACAO),
        ),
        protegerPacotes = true) { v ->
        "pm ${v[2]} ${v[0]} ${v[1]}"
    },
    Ferramenta("Apps", "Prioridade do app", "Controla o uso em 2º plano", Icons.Default.Settings,
        campos = listOf(
            Campo("Pacote", TipoCampo.PACOTE),
            Campo("Nível", TipoCampo.BUCKET),
        ),
        protegerPacotes = true) { v ->
        "am set-standby-bucket ${v[0]} ${v[1]}"
    },
    Ferramenta("Apps", "Remover bloatware", "Desinstala só para você", Icons.Default.Warning,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE)),
        aviso = "Remove só para o usuário atual. Dá para restaurar com \"Restaurar app\".",
        protegerPacotes = true) { v ->
        "pm uninstall -k --user 0 ${v[0]}"
    },
    Ferramenta("Apps", "Restaurar app", "Volta um app removido", Icons.Default.Refresh,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE))) { v ->
        "pm install-existing --user 0 ${v[0]}"
    },

    // ---- Sistema ----
    Ferramenta("Sistema", "Limite em 2º plano", "Processos em cache", Icons.Default.Settings,
        campos = listOf(Campo("Máx. processos", TipoCampo.NUMERO, 4..256)),
        aviso = "Só Android 12+. Alguns fabricantes ignoram ou sobrescrevem este valor.") { v ->
        "device_config put activity_manager max_cached_processes ${v[0]}"
    },
    Ferramenta("Sistema", "Restaurar limite", "Volta ao padrão do sistema", Icons.Default.Refresh) {
        "device_config delete activity_manager max_cached_processes"
    },
    Ferramenta("Sistema", "Modo economia", "Liga ou desliga a economia", Icons.Default.Settings,
        campos = listOf(Campo("1 liga, 0 desliga", TipoCampo.NUMERO, 0..1))) { v ->
        "settings put global low_power ${v[0]}"
    },
    Ferramenta("Sistema", "Forçar Doze", "Suspensão profunda agora", Icons.Default.Lock,
        aviso = "Pode pausar notificações e sincronização. Use \"Sair do Doze\" para voltar.") {
        "dumpsys deviceidle force-idle"
    },
    Ferramenta("Sistema", "Sair do Doze", "Volta ao normal", Icons.Default.Refresh) {
        "dumpsys deviceidle unforce"
    },
    Ferramenta("Sistema", "Phantom processes", "Libera o limite do Android 12+", Icons.Default.Warning,
        campos = listOf(Campo("1 libera, 0 restaura", TipoCampo.NUMERO, 0..1)),
        aviso = "Só Android 12+. Alguns fabricantes ignoram.") { v ->
        if (v[0] == "1") {
            "device_config put activity_manager max_phantom_processes 2147483647; " +
                "settings put global settings_enable_monitor_phantom_procs false"
        } else {
            "device_config delete activity_manager max_phantom_processes; " +
                "settings put global settings_enable_monitor_phantom_procs true"
        }
    },

    Ferramenta("Info", "Bateria", "Nível, temperatura e saúde", Icons.Default.Info,
        mostrarSaida = true) {
        "dumpsys battery"
    },
    Ferramenta("Info", "Sistema", "Modelo, Android e tela", Icons.Default.Info,
        mostrarSaida = true) {
        "echo -n 'Modelo: '; getprop ro.product.model; " +
            "echo -n 'Android: '; getprop ro.build.version.release; " +
            "echo -n 'API: '; getprop ro.build.version.sdk; " +
            "echo -n 'CPU ABI: '; getprop ro.product.cpu.abi; " +
            "wm size; wm density"
    },
    Ferramenta("Info", "Processos pesados", "Maiores consumidores", Icons.Default.Info,
        mostrarSaida = true) {
        "dumpsys meminfo | head -n 25; top -b -n 1 | head -n 15"
    },
)

data class Reversao(val comando: String, val segundos: Int)
data class Saida(val titulo: String, val texto: String)

const val MAX_AMOSTRAS: Int = 60

data class Amostra(
    val cpuTotal: Float,
    val nucleos: List<Float>,
    val ramPct: Float,
    val ramUsadaMb: Int,
    val ramTotalMb: Int,
    val swapUsadaMb: Int,
    val swapTotalMb: Int,
)

private const val COMANDO_MONITOR: String =
    "grep '^cpu' /proc/stat; grep -E '^(MemTotal|MemAvailable|SwapTotal|SwapFree):' /proc/meminfo"

private fun parseCpu(linhas: List<String>): Map<String, LongArray> {
    val mapa = LinkedHashMap<String, LongArray>()
    for (linha in linhas) {
        val partes = linha.trim().split(Regex("\\s+"))
        if (partes.size < 6 || !partes[0].startsWith("cpu")) continue
        mapa[partes[0]] = LongArray(partes.size - 1) { i -> partes[i + 1].toLongOrNull() ?: 0L }
    }
    return mapa
}

private fun parseMemoria(linhas: List<String>): Map<String, Long> {
    val mapa = HashMap<String, Long>()
    for (linha in linhas) {
        val partes = linha.trim().split(Regex("\\s+"))
        if (partes.size >= 2 && partes[0].endsWith(":")) {
            mapa[partes[0].removeSuffix(":")] = partes[1].toLongOrNull() ?: 0L
        }
    }
    return mapa
}

private fun usoCpu(antes: LongArray?, agora: LongArray?): Float? {
    if (antes == null || agora == null) return null
    val n = minOf(8, antes.size, agora.size)
    if (n < 5) return null
    var totalAntes = 0L
    var totalAgora = 0L
    for (i in 0 until n) {
        totalAntes += antes[i]
        totalAgora += agora[i]
    }
    val ociosoAntes = antes[3] + antes[4]
    val ociosoAgora = agora[3] + agora[4]
    val deltaTotal = totalAgora - totalAntes
    val deltaOcioso = ociosoAgora - ociosoAntes
    if (deltaTotal <= 0L) return null
    return (1f - deltaOcioso.toFloat() / deltaTotal.toFloat()).coerceIn(0f, 1f)
}

class OptimizerViewModel : ViewModel() {
    private val _estado = MutableStateFlow<ShizukuState>(ShizukuManager.estado())
    val estado: StateFlow<ShizukuState> = _estado.asStateFlow()

    private val _ocupado = MutableStateFlow<Boolean>(false)
    val ocupado: StateFlow<Boolean> = _ocupado.asStateFlow()

    private val _saida = MutableStateFlow<Saida?>(null)
    val saida: StateFlow<Saida?> = _saida.asStateFlow()

    private val _reversao = MutableStateFlow<Reversao?>(null)
    val reversao: StateFlow<Reversao?> = _reversao.asStateFlow()

    private val _mensagens = MutableSharedFlow<String>(
        extraBufferCapacity = 8,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    val mensagens: SharedFlow<String> = _mensagens.asSharedFlow()

    private val _historico = MutableStateFlow<List<Amostra>>(emptyList())
    val historico: StateFlow<List<Amostra>> = _historico.asStateFlow()

    private var jobReversao: Job? = null

    private val aoReceberBinder = Shizuku.OnBinderReceivedListener { atualizar() }
    private val aoPerderBinder = Shizuku.OnBinderDeadListener { atualizar() }
    private val aoResponderPermissao =
        Shizuku.OnRequestPermissionResultListener { _, _ -> atualizar() }

    init {
        Shizuku.addBinderReceivedListenerSticky(aoReceberBinder)
        Shizuku.addBinderDeadListener(aoPerderBinder)
        Shizuku.addRequestPermissionResultListener(aoResponderPermissao)
    }

    @OptIn(DelicateCoroutinesApi::class)
    override fun onCleared() {
        Shizuku.removeBinderReceivedListener(aoReceberBinder)
        Shizuku.removeBinderDeadListener(aoPerderBinder)
        Shizuku.removeRequestPermissionResultListener(aoResponderPermissao)
        // Se o app fechar com uma mudança de tela pendente, desfaz para não prender o usuário.
        val pendente = _reversao.value
        if (pendente != null) {
            GlobalScope.launch { ShizukuManager.executar(pendente.comando) }
        }
    }

    fun atualizar() {
        _estado.value = ShizukuManager.estado()
    }

    fun pedirPermissao() {
        val erro = ShizukuManager.pedirPermissao()
        if (erro != null) avisar(erro)
    }

    /** Laço do monitor: amostra a cada 1s até ser cancelado (ao sair da aba ou do app). */
    suspend fun coletarAmostras() {
        var anterior: Map<String, LongArray> = emptyMap()
        while (true) {
            val r = ShizukuManager.executar(COMANDO_MONITOR, 5_000L)
            if (r.ok) {
                val linhas: List<String> = r.saida.lines()
                val agora = parseCpu(linhas)
                val mem = parseMemoria(linhas)
                val total = usoCpu(anterior["cpu"], agora["cpu"])
                val chaves = agora.keys
                    .filter { it != "cpu" }
                    .sortedBy { it.removePrefix("cpu").toIntOrNull() ?: 0 }
                val nucleos: List<Float> = chaves.map { usoCpu(anterior[it], agora[it]) ?: 0f }
                val memTotalKb = mem["MemTotal"] ?: 0L
                val memDispKb = mem["MemAvailable"] ?: 0L
                val swapTotalKb = mem["SwapTotal"] ?: 0L
                val swapLivreKb = mem["SwapFree"] ?: 0L
                if (total != null && memTotalKb > 0L) {
                    val usadaKb = (memTotalKb - memDispKb).coerceAtLeast(0L)
                    val nova = Amostra(
                        cpuTotal = total,
                        nucleos = nucleos,
                        ramPct = usadaKb.toFloat() / memTotalKb.toFloat(),
                        ramUsadaMb = (usadaKb / 1024L).toInt(),
                        ramTotalMb = (memTotalKb / 1024L).toInt(),
                        swapUsadaMb = ((swapTotalKb - swapLivreKb).coerceAtLeast(0L) / 1024L).toInt(),
                        swapTotalMb = (swapTotalKb / 1024L).toInt(),
                    )
                    _historico.value = (_historico.value + nova).takeLast(MAX_AMOSTRAS)
                }
                if (agora.isNotEmpty()) anterior = agora
            }
            delay(1000)
        }
    }

    fun fecharSaida() {
        _saida.value = null
    }

    fun executar(f: Ferramenta, valoresBrutos: List<String>) {
        if (_ocupado.value) {
            avisar("Aguarde o comando anterior terminar")
            return
        }
        if (_reversao.value != null) {
            avisar("Confirme ou reverta a alteração pendente")
            return
        }
        val valores: List<String> = valoresBrutos.map { it.trim() }
        val erro = validarCampos(f, valores)
        if (erro != null) {
            avisar(erro)
            return
        }
        val comando = f.montar(valores)
        _ocupado.value = true
        viewModelScope.launch {
            try {
                val r = ShizukuManager.executar(comando, f.timeoutSeg * 1000L)
                tratarResultado(f, r)
            } finally {
                _ocupado.value = false
            }
        }
    }

    private fun tratarResultado(f: Ferramenta, r: Resultado) {
        val desfazer: String? = f.reverter
        if (!r.ok) {
            val detalhe = r.saida.take(150).ifBlank { "sem detalhes" }
            avisar("Falhou: $detalhe")
        } else if (f.mostrarSaida) {
            mostrarSaida(f.nome, r.saida)
        } else if (desfazer != null) {
            iniciarReversao(desfazer)
        } else {
            avisar("${f.nome}: concluído")
        }
    }

    private fun mostrarSaida(titulo: String, texto: String) {
        _saida.value = Saida(titulo, texto)
    }

    private fun iniciarReversao(comando: String) {
        jobReversao?.cancel()
        jobReversao = viewModelScope.launch {
            for (s in 10 downTo 1) {
                _reversao.value = Reversao(comando, s)
                delay(1000)
            }
            reverterAgora(comando)
        }
    }

    fun manter() {
        jobReversao?.cancel()
        _reversao.value = null
        avisar("Alteração mantida")
    }

    fun reverter() {
        val atual = _reversao.value
        if (atual == null) return
        jobReversao?.cancel()
        reverterAgora(atual.comando)
    }

    private fun reverterAgora(comando: String) {
        _reversao.value = null
        viewModelScope.launch {
            val r = ShizukuManager.executar(comando)
            if (r.ok) {
                avisar("Alteração revertida")
            } else {
                avisar("Falha ao reverter: ${r.saida.take(100)}")
            }
        }
    }

    private fun avisar(texto: String) {
        _mensagens.tryEmit(texto)
    }
}
