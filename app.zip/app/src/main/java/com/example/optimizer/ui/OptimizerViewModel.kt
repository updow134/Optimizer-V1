package com.example.optimizer.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

/** Tipos de campo: cada um valida a entrada (e garante que ela é segura para o shell). */
enum class TipoCampo(val dica: String, val regex: Regex) {
    NUMERO("somente números", Regex("^[0-9]{1,5}$")),
    ESCALA("use 0, 0.5, 1, 1.5 ou 2", Regex("^(0|0\\.5|1|1\\.5|2)$")),
    RESOLUCAO("ex: 1080x2400", Regex("^[0-9]{3,5}x[0-9]{3,5}$")),
    PACOTE("ex: com.app.exemplo", Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")),
    PERMISSAO("ex: android.permission.CAMERA", Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")),
    ACAO("grant ou revoke", Regex("^(grant|revoke)$")),
}

data class Campo(val rotulo: String, val tipo: TipoCampo, val faixa: IntRange? = null)

data class Ferramenta(
    val categoria: String,
    val nome: String,
    val descricao: String,
    val icone: ImageVector,
    val campos: List<Campo> = emptyList(),
    val aviso: String? = null,
    val reverter: String? = null,          // comando de desfazer (contagem de 10s)
    val mostrarSaida: Boolean = false,
    val protegerPacotes: Boolean = false,  // bloqueia apps essenciais do sistema
    val timeoutSeg: Int = 60,
    val montar: (List<String>) -> String,  // valores já validados
)

private val PACOTES_PROTEGIDOS: Set<String> = setOf(
    "com.android.systemui", "com.android.phone", "com.android.settings",
    "com.android.launcher3", "com.google.android.gms", "com.google.android.gsf",
    "com.android.vending", "moe.shizuku.privileged.api", "com.example.optimizer",
)

private fun pacoteProtegido(p: String): Boolean =
    p in PACOTES_PROTEGIDOS ||
        p.startsWith("com.android.providers.") ||
        p.startsWith("com.android.inputmethod")

/** Devolve a mensagem de erro, ou null se tudo estiver válido. */
fun validarCampos(f: Ferramenta, valores: List<String>): String? {
    if (valores.size != f.campos.size) return "Preencha todos os campos"
    for (i in f.campos.indices) {
        val campo = f.campos[i]
        val v = valores[i]
        if (!campo.tipo.regex.matches(v)) return "${campo.rotulo}: ${campo.tipo.dica}"
        val faixa = campo.faixa
        if (faixa != null) {
            val n = v.toIntOrNull()
            if (n == null || n !in faixa) {
                return "${campo.rotulo}: use de ${faixa.first} a ${faixa.last}"
            }
        }
        if (f.protegerPacotes && campo.tipo == TipoCampo.PACOTE && pacoteProtegido(v)) {
            return "Pacote protegido: mexer nele pode quebrar o sistema"
        }
    }
    return null
}

val FERRAMENTAS: List<Ferramenta> = listOf(
    // ---- Rápidas ----
    Ferramenta("Rápidas", "Limpar cache", "Libera espaço dos apps", Icons.Default.Delete,
        timeoutSeg = 120) {
        "pm trim-caches 999G"
    },
    Ferramenta("Rápidas", "Compilar ART", "Modo speed nos apps", Icons.Default.Build,
        aviso = "Pode levar vários minutos e esquentar o aparelho. Mantenha o app aberto.",
        timeoutSeg = 900) {
        "cmd package compile -m speed -a"
    },
    Ferramenta("Rápidas", "Animações", "Escala 0.5x / 0x", Icons.Default.PlayArrow,
        campos = listOf(Campo("Escala", TipoCampo.ESCALA))) { v ->
        "settings put global window_animation_scale ${v[0]}; " +
            "settings put global transition_animation_scale ${v[0]}; " +
            "settings put global animator_duration_scale ${v[0]}"
    },
    Ferramenta("Rápidas", "Congelar app", "Desativa um app", Icons.Default.Lock,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE)), protegerPacotes = true) { v ->
        "pm disable-user --user 0 ${v[0]}"
    },

    // ---- Tela ----
    Ferramenta("Tela", "DPI", "Densidade da tela", Icons.Default.Edit,
        campos = listOf(Campo("DPI", TipoCampo.NUMERO, 120..800)),
        aviso = "Reverte sozinho em 10s se você não confirmar.",
        reverter = "wm density reset") { v ->
        "wm density ${v[0]}"
    },
    Ferramenta("Tela", "Resolução", "Reduz para ganhar fluidez", Icons.Default.Search,
        campos = listOf(Campo("Resolução", TipoCampo.RESOLUCAO)),
        aviso = "Reverte sozinho em 10s se você não confirmar.",
        reverter = "wm size reset") { v ->
        "wm size ${v[0]}"
    },
    Ferramenta("Tela", "Taxa de atualização", "60 / 90 / 120 Hz", Icons.Default.Refresh,
        campos = listOf(Campo("Hz", TipoCampo.NUMERO, 0..240)),
        aviso = "Use 0 para restaurar o padrão do sistema.") { v ->
        if (v[0] == "0") {
            "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
        } else {
            "settings put system min_refresh_rate ${v[0]}; settings put system peak_refresh_rate ${v[0]}"
        }
    },

    // ---- Apps ----
    Ferramenta("Apps", "Forçar parada", "Encerra um app agora", Icons.Default.Close,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE)), protegerPacotes = true) { v ->
        "am force-stop ${v[0]}"
    },
    Ferramenta("Apps", "Descongelar app", "Reativa um app", Icons.Default.Lock,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE))) { v ->
        "pm enable ${v[0]}"
    },
    Ferramenta("Apps", "Permissões", "Conceder ou revogar", Icons.Default.Person,
        campos = listOf(
            Campo("Pacote", TipoCampo.PACOTE),
            Campo("Permissão", TipoCampo.PERMISSAO),
            Campo("Ação", TipoCampo.ACAO),
        ),
        protegerPacotes = true) { v ->
        "pm ${v[2]} ${v[0]} ${v[1]}"
    },
    Ferramenta("Apps", "Remover bloatware", "Desinstala só para você", Icons.Default.Warning,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE)),
        aviso = "Remove só para o usuário atual. Dá para restaurar com \"Restaurar app\".",
        protegerPacotes = true) { v ->
        "pm uninstall -k --user 0 ${v[0]}"
    },
    Ferramenta("Apps", "Restaurar app", "Volta um app removido", Icons.Default.Refresh,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE))) { v ->
        "pm install-existing --user 0 ${v[0]}"
    },

    // ---- Sistema ----
    Ferramenta("Sistema", "Limite em 2º plano", "Processos em cache", Icons.Default.Settings,
        campos = listOf(Campo("Máx. processos", TipoCampo.NUMERO, 4..256)),
        aviso = "Só Android 12+. Alguns fabricantes ignoram ou sobrescrevem este valor.") { v ->
        "device_config put activity_manager max_cached_processes ${v[0]}"
    },
    Ferramenta("Sistema", "Restaurar limite", "Volta ao padrão do sistema", Icons.Default.Refresh) {
        "device_config delete activity_manager max_cached_processes"
    },
    Ferramenta("Sistema", "Monitor RAM/CPU", "Uso em tempo real", Icons.Default.Info,
        mostrarSaida = true) {
        "dumpsys meminfo | head -n 25; top -b -n 1 | head -n 12"
    },
)

data class Reversao(val comando: String, val segundos: Int)
data class Saida(val titulo: String, val texto: String)

class OptimizerViewModel : ViewModel() {
    private val _estado = MutableStateFlow<ShizukuState>(ShizukuManager.estado())
    val estado: StateFlow<ShizukuState> = _estado.asStateFlow()

    private val _ocupado = MutableStateFlow<Boolean>(false)
    val ocupado: StateFlow<Boolean> = _ocupado.asStateFlow()

    private val _saida = MutableStateFlow<Saida?>(null)
    val saida: StateFlow<Saida?> = _saida.asStateFlow()

    private val _reversao = MutableStateFlow<Reversao?>(null)
    val reversao: StateFlow<Reversao?> = _reversao.asStateFlow()

    private val _mensagens = MutableSharedFlow<String>(
        extraBufferCapacity = 8,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    val mensagens: SharedFlow<String> = _mensagens.asSharedFlow()

    private var jobReversao: Job? = null

    private val aoReceberBinder = Shizuku.OnBinderReceivedListener { atualizar() }
    private val aoPerderBinder = Shizuku.OnBinderDeadListener { atualizar() }
    private val aoResponderPermissao =
        Shizuku.OnRequestPermissionResultListener { _, _ -> atualizar() }

    init {
        Shizuku.addBinderReceivedListenerSticky(aoReceberBinder)
        Shizuku.addBinderDeadListener(aoPerderBinder)
        Shizuku.addRequestPermissionResultListener(aoResponderPermissao)
    }

    @OptIn(DelicateCoroutinesApi::class)
    override fun onCleared() {
        Shizuku.removeBinderReceivedListener(aoReceberBinder)
        Shizuku.removeBinderDeadListener(aoPerderBinder)
        Shizuku.removeRequestPermissionResultListener(aoResponderPermissao)
        // Se o app fechar com uma mudança de tela pendente, desfaz para não prender o usuário.
        val pendente = _reversao.value
        if (pendente != null) {
            GlobalScope.launch { ShizukuManager.executar(pendente.comando) }
        }
    }

    fun atualizar() {
        _estado.value = ShizukuManager.estado()
    }

    fun pedirPermissao() {
        val erro = ShizukuManager.pedirPermissao()
        if (erro != null) avisar(erro)
    }

    fun fecharSaida() {
        _saida.value = null
    }

    fun executar(f: Ferramenta, valoresBrutos: List<String>) {
        if (_ocupado.value) {
            avisar("Aguarde o comando anterior terminar")
            return
        }
        if (_reversao.value != null) {
            avisar("Confirme ou reverta a alteração pendente")
            return
        }
        val valores: List<String> = valoresBrutos.map { it.trim() }
        val erro = validarCampos(f, valores)
        if (erro != null) {
            avisar(erro)
            return
        }
        val comando = f.montar(valores)
        _ocupado.value = true
        viewModelScope.launch {
            try {
                val r = ShizukuManager.executar(comando, f.timeoutSeg * 1000L)
                tratarResultado(f, r)
            } finally {
                _ocupado.value = false
            }
        }
    }

    private fun tratarResultado(f: Ferramenta, r: Resultado) {
        val desfazer: String? = f.reverter
        if (!r.ok) {
            val detalhe = r.saida.take(150).ifBlank { "sem detalhes" }
            avisar("Falhou: $detalhe")
        } else if (f.mostrarSaida) {
            mostrarSaida(f.nome, r.saida)
        } else if (desfazer != null) {
            iniciarReversao(desfazer)
        } else {
            avisar("${f.nome}: concluído")
        }
    }

    private fun mostrarSaida(titulo: String, texto: String) {
        _saida.value = Saida(titulo, texto)
    }

    private fun iniciarReversao(comando: String) {
        jobReversao?.cancel()
        jobReversao = viewModelScope.launch {
            for (s in 10 downTo 1) {
                _reversao.value = Reversao(comando, s)
                delay(1000)
            }
            reverterAgora(comando)
        }
    }

    fun manter() {
        jobReversao?.cancel()
        _reversao.value = null
        avisar("Alteração mantida")
    }

    fun reverter() {
        val atual = _reversao.value
        if (atual == null) return
        jobReversao?.cancel()
        reverterAgora(atual.comando)
    }

    private fun reverterAgora(comando: String) {
        _reversao.value = null
        viewModelScope.launch {
            val r = ShizukuManager.executar(comando)
            if (r.ok) {
                avisar("Alteração revertida")
            } else {
                avisar("Falha ao reverter: ${r.saida.take(100)}")
            }
        }
    }

    private fun avisar(texto: String) {
        _mensagens.tryEmit(texto)
    }
}
