package com.example.optimizer.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.graphics.vector.ImageVector
import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import rikka.shizuku.Shizuku

/** Tipos de campo: cada um valida a entrada (e garante que ela é segura para o shell). */
enum class TipoCampo(val dica: String, val regex: Regex) {
    NUMERO("somente números", Regex("^[0-9]{1,5}$")),
    ESCALA("use 0, 0.5, 1, 1.5 ou 2", Regex("^(0|0\\.5|1|1\\.5|2)$")),
    RESOLUCAO("ex: 1080x2400", Regex("^[0-9]{3,5}x[0-9]{3,5}$")),
    PACOTE("ex: com.app.exemplo", Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")),
    PERMISSAO("ex: android.permission.CAMERA", Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")),
    ACAO("grant ou revoke", Regex("^(grant|revoke)$")),
    BUCKET(
        "active, working_set, frequent, rare ou restricted",
        Regex("^(active|working_set|frequent|rare|restricted)$"),
    ),
}

data class Campo(val rotulo: String, val tipo: TipoCampo, val faixa: IntRange? = null)

data class Ferramenta(
    val categoria: String,
    val nome: String,
    val descricao: String,
    val icone: ImageVector,
    val campos: List<Campo> = emptyList(),
    val aviso: String? = null,
    val reverter: String? = null,          // comando de desfazer (contagem de 10s)
    val mostrarSaida: Boolean = false,
    val protegerPacotes: Boolean = false,  // bloqueia apps essenciais do sistema
    val timeoutSeg: Int = 60,
    val montar: (List<String>) -> String,  // valores já validados
)

private val PACOTES_PROTEGIDOS: Set<String> = setOf(
    "com.android.systemui", "com.android.phone", "com.android.settings",
    "com.android.launcher3", "com.google.android.gms", "com.google.android.gsf",
    "com.android.vending", "moe.shizuku.privileged.api", "com.example.optimizer",
)

private fun pacoteProtegido(p: String): Boolean =
    p in PACOTES_PROTEGIDOS ||
        p.startsWith("com.android.providers.") ||
        p.startsWith("com.android.inputmethod")

/** Devolve a mensagem de erro, ou null se tudo estiver válido. */
fun validarCampos(f: Ferramenta, valores: List<String>): String? {
    if (valores.size != f.campos.size) return "Preencha todos os campos"
    for (i in f.campos.indices) {
        val campo = f.campos[i]
        val v = valores[i]
        if (!campo.tipo.regex.matches(v)) return "${campo.rotulo}: ${campo.tipo.dica}"
        val faixa = campo.faixa
        if (faixa != null) {
            val n = v.toIntOrNull()
            if (n == null || n !in faixa) {
                return "${campo.rotulo}: use de ${faixa.first} a ${faixa.last}"
            }
        }
        if (f.protegerPacotes && campo.tipo == TipoCampo.PACOTE && pacoteProtegido(v)) {
            return "Pacote protegido: mexer nele pode quebrar o sistema"
        }
    }
    return null
}

val FERRAMENTAS: List<Ferramenta> = listOf(
    // ---- Rápidas ----
    Ferramenta("Rápidas", "Limpar cache", "Libera espaço dos apps", Icons.Default.Delete,
        timeoutSeg = 120) {
        "pm trim-caches 999G"
    },
    Ferramenta("Rápidas", "Limpar RAM", "Encerra apps em 2º plano", Icons.Default.Close,
        timeoutSeg = 30) {
        "am kill-all"
    },
    Ferramenta("Rápidas", "Compilar ART", "Modo speed nos apps", Icons.Default.Build,
        aviso = "Pode levar vários minutos e esquentar o aparelho. Mantenha o app aberto.",
        timeoutSeg = 900) {
        "cmd package compile -m speed -a"
    },
    Ferramenta("Rápidas", "Animações", "Escala 0.5x / 0x", Icons.Default.PlayArrow,
        campos = listOf(Campo("Escala", TipoCampo.ESCALA))) { v ->
        "settings put global window_animation_scale ${v[0]}; " +
            "settings put global transition_animation_scale ${v[0]}; " +
            "settings put global animator_duration_scale ${v[0]}"
    },
    Ferramenta("Rápidas", "Congelar app", "Desativa um app", Icons.Default.Lock,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE)), protegerPacotes = true) { v ->
        "pm disable-user --user 0 ${v[0]}"
    },

    // ---- Tela ----
    Ferramenta("Tela", "DPI", "Densidade da tela", Icons.Default.Edit,
        campos = listOf(Campo("DPI", TipoCampo.NUMERO, 120..800)),
        aviso = "Reverte sozinho em 10s se você não confirmar.",
        reverter = "wm density reset") { v ->
        "wm density ${v[0]}"
    },
    Ferramenta("Tela", "Resolução", "Reduz para ganhar fluidez", Icons.Default.Search,
        campos = listOf(Campo("Resolução", TipoCampo.RESOLUCAO)),
        aviso = "Reverte sozinho em 10s se você não confirmar.",
        reverter = "wm size reset") { v ->
        "wm size ${v[0]}"
    },
    Ferramenta("Tela", "Taxa de atualização", "60 / 90 / 120 Hz", Icons.Default.Refresh,
        campos = listOf(Campo("Hz", TipoCampo.NUMERO, 0..240)),
        aviso = "Use 0 para restaurar o padrão do sistema.") { v ->
        if (v[0] == "0") {
            "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
        } else {
            "settings put system min_refresh_rate ${v[0]}; settings put system peak_refresh_rate ${v[0]}"
        }
    },

    // ---- Apps ----
    Ferramenta("Apps", "Forçar parada", "Encerra um app agora", Icons.Default.Close,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE)), protegerPacotes = true) { v ->
        "am force-stop ${v[0]}"
    },
    Ferramenta("Apps", "Descongelar app", "Reativa um app", Icons.Default.Lock,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE))) { v ->
        "pm enable ${v[0]}"
    },
    Ferramenta("Apps", "Permissões", "Conceder ou revogar", Icons.Default.Person,
        campos = listOf(
            Campo("Pacote", TipoCampo.PACOTE),
            Campo("Permissão", TipoCampo.PERMISSAO),
            Campo("Ação", TipoCampo.ACAO),
        ),
        protegerPacotes = true) { v ->
        "pm ${v[2]} ${v[0]} ${v[1]}"
    },
    Ferramenta("Apps", "Prioridade do app", "Controla o uso em 2º plano", Icons.Default.Settings,
        campos = listOf(
            Campo("Pacote", TipoCampo.PACOTE),
            Campo("Nível", TipoCampo.BUCKET),
        ),
        protegerPacotes = true) { v ->
        "am set-standby-bucket ${v[0]} ${v[1]}"
    },
    Ferramenta("Apps", "Remover bloatware", "Desinstala só para você", Icons.Default.Warning,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE)),
        aviso = "Remove só para o usuário atual. Dá para restaurar com \"Restaurar app\".",
        protegerPacotes = true) { v ->
        "pm uninstall -k --user 0 ${v[0]}"
    },
    Ferramenta("Apps", "Restaurar app", "Volta um app removido", Icons.Default.Refresh,
        campos = listOf(Campo("Pacote", TipoCampo.PACOTE))) { v ->
        "pm install-existing --user 0 ${v[0]}"
    },

    // ---- Sistema ----
    Ferramenta("Sistema", "Limite em 2º plano", "Processos em cache", Icons.Default.Settings,
        campos = listOf(Campo("Máx. processos", TipoCampo.NUMERO, 4..256)),
        aviso = "Só Android 12+. Alguns fabricantes ignoram ou sobrescrevem este valor.") { v ->
        "device_config put activity_manager max_cached_processes ${v[0]}"
    },
    Ferramenta("Sistema", "Restaurar limite", "Volta ao padrão do sistema", Icons.Default.Refresh) {
        "device_config delete activity_manager max_cached_processes"
    },
    Ferramenta("Sistema", "Modo economia", "Liga ou desliga a economia", Icons.Default.Settings,
        campos = listOf(Campo("1 liga, 0 desliga", TipoCampo.NUMERO, 0..1))) { v ->
        "settings put global low_power ${v[0]}"
    },
    Ferramenta("Sistema", "Forçar Doze", "Suspensão profunda agora", Icons.Default.Lock,
        aviso = "Pode pausar notificações e sincronização. Use \"Sair do Doze\" para voltar.") {
        "dumpsys deviceidle force-idle"
    },
    Ferramenta("Sistema", "Sair do Doze", "Volta ao normal", Icons.Default.Refresh) {
        "dumpsys deviceidle unforce"
    },
    Ferramenta("Sistema", "Phantom processes", "Libera o limite do Android 12+", Icons.Default.Warning,
        campos = listOf(Campo("1 libera, 0 restaura", TipoCampo.NUMERO, 0..1)),
        aviso = "Só Android 12+. Alguns fabricantes ignoram.") { v ->
        if (v[0] == "1") {
            "device_config put activity_manager max_phantom_processes 2147483647; " +
                "settings put global settings_enable_monitor_phantom_procs false"
        } else {
            "device_config delete activity_manager max_phantom_processes; " +
                "settings put global settings_enable_monitor_phantom_procs true"
        }
    },

    Ferramenta("Info", "Bateria", "Nível, temperatura e saúde", Icons.Default.Info,
        mostrarSaida = true) {
        "dumpsys battery"
    },
    Ferramenta("Info", "Sistema", "Modelo, Android e tela", Icons.Default.Info,
        mostrarSaida = true) {
        "echo -n 'Modelo: '; getprop ro.product.model; " +
            "echo -n 'Android: '; getprop ro.build.version.release; " +
            "echo -n 'API: '; getprop ro.build.version.sdk; " +
            "echo -n 'CPU ABI: '; getprop ro.product.cpu.abi; " +
            "wm size; wm density"
    },
    Ferramenta("Info", "Processos pesados", "Maiores consumidores", Icons.Default.Info,
        mostrarSaida = true) {
        "dumpsys meminfo | head -n 25; top -b -n 1 | head -n 15"
    },
)

data class Reversao(val comando: String, val segundos: Int)
data class Saida(val titulo: String, val texto: String)

const val MAX_AMOSTRAS: Int = 60

data class Amostra(
    val cpuTotal: Float,
    val nucleos: List<Float>,
    val ramPct: Float,
    val ramUsadaMb: Int,
    val ramTotalMb: Int,
    val swapUsadaMb: Int,
    val swapTotalMb: Int,
)

private const val COMANDO_MONITOR: String =
    "grep '^cpu' /proc/stat; grep -E '^(MemTotal|MemAvailable|SwapTotal|SwapFree):' /proc/meminfo"

private fun parseCpu(linhas: List<String>): Map<String, LongArray> {
    val mapa = LinkedHashMap<String, LongArray>()
    for (linha in linhas) {
        val partes = linha.trim().split(Regex("\\s+"))
        if (partes.size < 6 || !partes[0].startsWith("cpu")) continue
        mapa[partes[0]] = LongArray(partes.size - 1) { i -> partes[i + 1].toLongOrNull() ?: 0L }
    }
    return mapa
}

private fun parseMemoria(linhas: List<String>): Map<String, Long> {
    val mapa = HashMap<String, Long>()
    for (linha in linhas) {
        val partes = linha.trim().split(Regex("\\s+"))
        if (partes.size >= 2 && partes[0].endsWith(":")) {
            mapa[partes[0].removeSuffix(":")] = partes[1].toLongOrNull() ?: 0L
        }
    }
    return mapa
}

private fun usoCpu(antes: LongArray?, agora: LongArray?): Float? {
    if (antes == null || agora == null) return null
    val n = minOf(8, antes.size, agora.size)
    if (n < 5) return null
    var totalAntes = 0L
    var totalAgora = 0L
    for (i in 0 until n) {
        totalAntes += antes[i]
        totalAgora += agora[i]
    }
    val ociosoAntes = antes[3] + antes[4]
    val ociosoAgora = agora[3] + agora[4]
    val deltaTotal = totalAgora - totalAntes
    val deltaOcioso = ociosoAgora - ociosoAntes
    if (deltaTotal <= 0L) return null
    return (1f - deltaOcioso.toFloat() / deltaTotal.toFloat()).coerceIn(0f, 1f)
}

class OptimizerViewModel(application: Application) : AndroidViewModel(application) {
    private val _estado = MutableStateFlow<ShizukuState>(ShizukuManager.estado())
    val estado: StateFlow<ShizukuState> = _estado.asStateFlow()

    private val _ocupado = MutableStateFlow<Boolean>(false)
    val ocupado: StateFlow<Boolean> = _ocupado.asStateFlow()

    private val _saida = MutableStateFlow<Saida?>(null)
    val saida: StateFlow<Saida?> = _saida.asStateFlow()

    private val _reversao = MutableStateFlow<Reversao?>(null)
    val reversao: StateFlow<Reversao?> = _reversao.asStateFlow()

    private val _mensagens = MutableSharedFlow<String>(
        extraBufferCapacity = 8,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    val mensagens: SharedFlow<String> = _mensagens.asSharedFlow()

    private val _historico = MutableStateFlow<List<Amostra>>(emptyList())
    val historico: StateFlow<List<Amostra>> = _historico.asStateFlow()

    private val _foco = MutableStateFlow<FocoJogo?>(null)
    val foco: StateFlow<FocoJogo?> = _foco.asStateFlow()

    private val _pacto = MutableStateFlow<Pacto?>(null)
    val pacto: StateFlow<Pacto?> = _pacto.asStateFlow()

    private val _partida = MutableStateFlow(PartidaEstado())
    val partida: StateFlow<PartidaEstado> = _partida.asStateFlow()

    private val _relato = MutableStateFlow<Relato?>(null)
    val relato: StateFlow<Relato?> = _relato.asStateFlow()

    private val prefs = application.getSharedPreferences("optimizer-hub", Context.MODE_PRIVATE)
    private var snap: SnapPartida? = null
    private var alvoHz: Int = 60
    private var alvoRes: Float = 1f
    private var alvoDriver: Int = 1
    private var fator: Float = 1f
    private var driverAtual: Int = 1
    private var folga: Int = 0
    private var picoTemp: Float = 0f
    private var cortes: Int = 0
    private var picosPing: Int = 0
    private var somaPing: Int = 0
    private var nPing: Int = 0
    private var pacoteJogo: String = ""
    private var jobPartida: Job? = null
    private val sessao = Mutex()
    private var jobReversao: Job? = null

    private val aoReceberBinder = Shizuku.OnBinderReceivedListener { atualizar() }
    private val aoPerderBinder = Shizuku.OnBinderDeadListener { atualizar() }
    private val aoResponderPermissao =
        Shizuku.OnRequestPermissionResultListener { _, _ -> atualizar() }

    init {
        Shizuku.addBinderReceivedListenerSticky(aoReceberBinder)
        Shizuku.addBinderDeadListener(aoPerderBinder)
        Shizuku.addRequestPermissionResultListener(aoResponderPermissao)
        PonteLucy.aoDriver = { nivel -> definirDriver(nivel) }
    }

    @OptIn(DelicateCoroutinesApi::class)
    override fun onCleared() {
        Shizuku.removeBinderReceivedListener(aoReceberBinder)
        Shizuku.removeBinderDeadListener(aoPerderBinder)
        Shizuku.removeRequestPermissionResultListener(aoResponderPermissao)
        PonteLucy.aoDriver = null
        // Se o app fechar com uma mudança de tela pendente, desfaz para não prender o usuário.
        val pendente = _reversao.value
        val sessao = snap
        if (pendente != null || sessao != null) {
            GlobalScope.launch {
                if (pendente != null) ShizukuManager.executar(pendente.comando)
                if (sessao != null) restaurar(sessao)
            }
        }
    }

    fun atualizar() {
        _estado.value = ShizukuManager.estado()
    }

    fun pedirPermissao() {
        val erro = ShizukuManager.pedirPermissao()
        if (erro != null) avisar(erro)
    }

    /** Laço do monitor: amostra a cada 1s até ser cancelado (ao sair da aba ou do app). */
    suspend fun coletarAmostras() {
        var anterior: Map<String, LongArray> = emptyMap()
        while (true) {
            val r = ShizukuManager.executar(COMANDO_MONITOR, 5_000L)
            if (r.ok) {
                val linhas: List<String> = r.saida.lines()
                val agora = parseCpu(linhas)
                val mem = parseMemoria(linhas)
                val total = usoCpu(anterior["cpu"], agora["cpu"])
                val chaves = agora.keys
                    .filter { it != "cpu" }
                    .sortedBy { it.removePrefix("cpu").toIntOrNull() ?: 0 }
                val nucleos: List<Float> = chaves.map { usoCpu(anterior[it], agora[it]) ?: 0f }
                val memTotalKb = mem["MemTotal"] ?: 0L
                val memDispKb = mem["MemAvailable"] ?: 0L
                val swapTotalKb = mem["SwapTotal"] ?: 0L
                val swapLivreKb = mem["SwapFree"] ?: 0L
                if (total != null && memTotalKb > 0L) {
                    val usadaKb = (memTotalKb - memDispKb).coerceAtLeast(0L)
                    val nova = Amostra(
                        cpuTotal = total,
                        nucleos = nucleos,
                        ramPct = usadaKb.toFloat() / memTotalKb.toFloat(),
                        ramUsadaMb = (usadaKb / 1024L).toInt(),
                        ramTotalMb = (memTotalKb / 1024L).toInt(),
                        swapUsadaMb = ((swapTotalKb - swapLivreKb).coerceAtLeast(0L) / 1024L).toInt(),
                        swapTotalMb = (swapTotalKb / 1024L).toInt(),
                    )
                    _historico.value = (_historico.value + nova).takeLast(MAX_AMOSTRAS)
                }
                if (agora.isNotEmpty()) anterior = agora
            }
            delay(1000)
        }
    }

    fun fecharSaida() {
        _saida.value = null
    }

    fun executar(f: Ferramenta, valoresBrutos: List<String>) {
        if (_ocupado.value) {
            avisar("Aguarde o comando anterior terminar")
            return
        }
        if (_reversao.value != null) {
            avisar("Confirme ou reverta a alteração pendente")
            return
        }
        val valores: List<String> = valoresBrutos.map { it.trim() }
        val erro = validarCampos(f, valores)
        if (erro != null) {
            avisar(erro)
            return
        }
        val comando = f.montar(valores)
        _ocupado.value = true
        viewModelScope.launch {
            try {
                val r = ShizukuManager.executar(comando, f.timeoutSeg * 1000L)
                tratarResultado(f, r)
            } finally {
                _ocupado.value = false
            }
        }
    }

    private fun tratarResultado(f: Ferramenta, r: Resultado) {
        val desfazer: String? = f.reverter
        if (!r.ok) {
            val detalhe = r.saida.take(150).ifBlank { "sem detalhes" }
            avisar("Falhou: $detalhe")
        } else if (f.mostrarSaida) {
            mostrarSaida(f.nome, r.saida)
        } else if (desfazer != null) {
            iniciarReversao(desfazer)
        } else {
            avisar("${f.nome}: concluído")
        }
    }

    private fun mostrarSaida(titulo: String, texto: String) {
        _saida.value = Saida(titulo, texto)
    }

    private fun iniciarReversao(comando: String) {
        jobReversao?.cancel()
        jobReversao = viewModelScope.launch {
            for (s in 10 downTo 1) {
                _reversao.value = Reversao(comando, s)
                delay(1000)
            }
            reverterAgora(comando)
        }
    }

    fun manter() {
        jobReversao?.cancel()
        _reversao.value = null
        avisar("Alteração mantida")
    }

    fun reverter() {
        val atual = _reversao.value
        if (atual == null) return
        jobReversao?.cancel()
        reverterAgora(atual.comando)
    }

    private fun reverterAgora(comando: String) {
        _reversao.value = null
        viewModelScope.launch {
            val r = ShizukuManager.executar(comando)
            if (r.ok) {
                avisar("Alteração revertida")
            } else {
                avisar("Falha ao reverter: ${r.saida.take(100)}")
            }
        }
    }

    private fun avisar(texto: String) {
        _mensagens.tryEmit(texto)
    }

    fun lerFoco() {
        if (_ocupado.value || _partida.value.ativa) return
        _ocupado.value = true
        viewModelScope.launch {
            try {
                val r = ShizukuManager.executar("dumpsys window", 8_000L)
                if (!r.ok) {
                    avisar(r.saida.take(120).ifBlank { "Não consegui ler a tela" })
                    return@launch
                }
                val pacote = extrairFoco(r.saida)
                if (pacote == null) {
                    avisar("Não achei um jogo na frente. Abre o jogo e lê de novo.")
                    return@launch
                }
                publicarFoco(pacote)
            } finally {
                _ocupado.value = false
            }
        }
    }

    fun adicionarPacote(pacote: String, nome: String) {
        if (!pacoteValido(pacote)) return
        val conhecido = reconhecer(pacote)
        val genero = conhecido?.genero ?: "App"
        val titulo = (conhecido?.nome ?: nome).trim().take(32).ifBlank { pacote.substringAfterLast('.') }
        prefs.edit().putString("jogo:$pacote", "$titulo|$genero").apply()
        _foco.value = FocoJogo(pacote, titulo, genero, true)
        _pacto.value = pactoDe(genero, ramGb())
    }

    fun definirJogo(nome: String, genero: String) {
        val atual = _foco.value ?: return
        val limpo = nome.trim().take(32)
        if (limpo.length < 2 || genero !in GENEROS_HUB) return
        prefs.edit().putString("jogo:${atual.pacote}", "$limpo|$genero").apply()
        _foco.value = FocoJogo(atual.pacote, limpo, genero, true)
        _pacto.value = pactoDe(genero, ramGb())
    }

    fun dispensarRelato() {
        _relato.value = null
    }

    fun podeBolha(): Boolean = Settings.canDrawOverlays(getApplication())

    fun segurarFundo() {
        val app = getApplication<Application>()
        if (Build.VERSION.SDK_INT >= 33) {
            val ok = app.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
            if (!ok) return
        }
        val intent = Intent(app, LucyBolhaService::class.java)
        if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(intent) else app.startService(intent)
    }

    fun ligarBolha() {
        val app = getApplication<Application>()
        if (!Settings.canDrawOverlays(app)) {
            avisar("Permita a Lucy sobre outros apps e toque de novo.")
            return
        }
        val intent = Intent(app, LucyBolhaService::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            app.startForegroundService(intent)
        } else {
            app.startService(intent)
        }
    }

    fun desligarBolha() {
        val app = getApplication<Application>()
        app.stopService(Intent(app, LucyBolhaService::class.java))
    }

    fun definirHz(hz: Int) {
        val pacto = _pacto.value ?: return
        if (hz !in setOf(60, 90, 120)) return
        _pacto.value = pacto.copy(hz = hz)
        if (!_partida.value.ativa) return
        viewModelScope.launch {
            sessao.withLock {
                alvoHz = hz
                aplicarHz(hz)
                _partida.value = _partida.value.copy(hz = hz, nota = "Hz foi para $hz.")
                espelharBolha()
            }
        }
    }

    fun definirAnimator(escala: String) {
        val pacto = _pacto.value ?: return
        if (escala !in setOf("0", "0.5", "1")) return
        _pacto.value = pacto.copy(animator = escala)
        if (!_partida.value.ativa) return
        viewModelScope.launch {
            sessao.withLock {
                aplicarAnim(escala)
                _partida.value = _partida.value.copy(nota = "Animação em $escala.")
                espelharBolha()
            }
        }
    }

    fun definirDriver(n: Int) {
        if (n !in 0..2) return
        val pacto = _pacto.value
        if (pacto != null) _pacto.value = pacto.copy(driver = n)
        PonteLucy.driver = n
        if (!_partida.value.ativa) return
        viewModelScope.launch {
            sessao.withLock {
                val gravado = snap ?: return@withLock
                if (!pacoteValido(pacoteJogo)) return@withLock
                driverAtual = n
                alvoDriver = n
                aplicarDriver(pacoteJogo, n, gravado)
                _partida.value = _partida.value.copy(
                    driver = n,
                    nota = "Driver ${nomeDriver(n)}. Se a imagem não mudar, fecha e abre o jogo.",
                )
                espelharBolha()
            }
        }
    }

    fun definirQuarentena(ligada: Boolean) {
        val pacto = _pacto.value ?: return
        _pacto.value = pacto.copy(quarentena = ligada)
        if (!_partida.value.ativa) return
        viewModelScope.launch {
            sessao.withLock {
                val gravado = snap ?: return@withLock
                if (ligada) {
                    travarFundo(gravado)
                } else {
                    for ((pacote, bucket) in gravado.buckets) {
                        if (!pacoteValido(pacote) || !bucket.matches(Regex("^[a-z0-9_]{1,20}$"))) continue
                        ShizukuManager.executar("am set-standby-bucket $pacote $bucket", 5_000L)
                    }
                }
                _partida.value = _partida.value.copy(
                    nota = if (ligada) "Fundo travado. O Discord continua livre." else "Fundo liberado.",
                )
                espelharBolha()
            }
        }
    }

    private fun espelharBolha() {
        val p = _partida.value
        PonteLucy.hz = p.hz
        PonteLucy.driver = p.driver
        PonteLucy.ping = p.ping
        PonteLucy.nota = p.nota
        PonteLucy.partida = p.ativa
    }

    fun entrarPartida() {
        val pacto = _pacto.value ?: return
        val foco = _foco.value ?: return
        if (_partida.value.ativa || _ocupado.value) return
        if (_reversao.value != null) {
            avisar("Confirme a densidade antes de entrar na partida.")
            return
        }
        if (pacto.hz !in setOf(60, 90, 120)) return
        if (pacto.animator !in setOf("0", "0.5", "1")) return
        _ocupado.value = true
        jobPartida?.cancel()
        jobPartida = viewModelScope.launch {
            try {
                val gravado = sessao.withLock {
                    val lido = capturar()
                    if (lido == null) {
                        avisar("Não consegui ler a tela atual. Nada foi mudado.")
                        null
                    } else {
                        snap = lido
                        alvoHz = pacto.hz
                        alvoRes = pacto.res
                        alvoDriver = pacto.driver
                        fator = pacto.res
                        driverAtual = pacto.driver
                        folga = 0
                        picoTemp = 0f
                        cortes = 0
                        picosPing = 0
                        somaPing = 0
                        nPing = 0
                        pacoteJogo = foco.pacote
                        aplicarHz(pacto.hz)
                        aplicarAnim(pacto.animator)
                        aplicarDriver(foco.pacote, pacto.driver, lido)
                        if (pacto.res < 0.98f) aplicarTela(pacto.res, lido.largura, lido.altura)
                        ShizukuManager.executar("settings put global low_power 0", 5_000L)
                        if (pacto.quarentena) travarFundo(lido)
                        _relato.value = null
                        _partida.value = PartidaEstado(
                            ativa = true,
                            nome = foco.nome,
                            hz = pacto.hz,
                            temp = null,
                            nota = "Pacto aplicado. Fecha e abre o jogo para o driver valer. Hz e tela já valem.",
                            driver = pacto.driver,
                        )
                        lido
                    }
                }
                if (gravado == null) return@launch
                espelharBolha()
                if (Settings.canDrawOverlays(getApplication())) ligarBolha()
                _ocupado.value = false
                while (true) {
                    delay(8_000)
                    sessao.withLock { governar(gravado) }
                }
            } finally {
                _ocupado.value = false
            }
        }
    }

    fun encerrarPartida() {
        jobPartida?.cancel()
        jobPartida = null
        viewModelScope.launch {
            sessao.withLock {
                val gravado = snap ?: return@withLock
                val media = if (nPing == 0) 0 else somaPing / nPing
                _relato.value = fecharRelato(_partida.value.nome, picoTemp, cortes, picosPing, media)
                restaurar(gravado)
                snap = null
                _partida.value = PartidaEstado()
                espelharBolha()
                avisar("Partida encerrada. Ajustes de antes foram devolvidos.")
            }
        }
    }

    private fun publicarFoco(pacote: String) {
        val salvo = prefs.getString("jogo:$pacote", null)
        val conhecido = reconhecer(pacote)
        val nome: String
        val genero: String
        val ok: Boolean
        if (salvo != null && salvo.contains("|")) {
            val partes = salvo.split("|", limit = 2)
            nome = partes[0]
            genero = partes[1]
            ok = true
        } else if (conhecido != null) {
            nome = conhecido.nome
            genero = conhecido.genero
            ok = true
        } else {
            nome = pacote.substringAfterLast('.')
            genero = "FPS"
            ok = false
        }
        _foco.value = FocoJogo(pacote, nome, genero, ok)
        _pacto.value = if (ok) pactoDe(genero, ramGb()) else null
    }

    private fun ramGb(): Int {
        val am = getApplication<Application>().getSystemService(ActivityManager::class.java)
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return (info.totalMem / (1024L * 1024L * 1024L)).toInt().coerceAtLeast(1)
    }

    private suspend fun capturar(): SnapPartida? {
        val tela = ShizukuManager.executar("wm size", 5_000L)
        val tamanho = if (tela.ok) lerTamanho(tela.saida) else null
        if (tamanho == null) return null
        val buckets = LinkedHashMap<String, String>()
        for ((pacote, travar) in FUNDO_PARTIDA) {
            if (!travar || !pacoteValido(pacote)) continue
            val caminho = ShizukuManager.executar("pm path $pacote", 5_000L)
            if (!caminho.ok || !caminho.saida.contains("package:")) continue
            val bucket = ShizukuManager.executar("am get-standby-bucket $pacote", 5_000L)
            val token = bucket.saida.trim().substringBefore(" ").lowercase()
            if (bucket.ok && token.matches(Regex("^[a-z0-9_]{1,20}$"))) buckets[pacote] = token
        }
        return SnapPartida(
            peak = lerSetting("system", "peak_refresh_rate"),
            minHz = lerSetting("system", "min_refresh_rate"),
            animWin = lerSetting("global", "window_animation_scale"),
            animTrans = lerSetting("global", "transition_animation_scale"),
            animDur = lerSetting("global", "animator_duration_scale"),
            lowPower = lerSetting("global", "low_power"),
            buckets = buckets,
            largura = tamanho.first,
            altura = tamanho.second,
            gameOptIn = lerSetting("global", "game_driver_opt_in_apps"),
            gameOptOut = lerSetting("global", "game_driver_opt_out_apps"),
            anglePkgs = lerSetting("global", "angle_gl_driver_selection_pkgs"),
            angleVals = lerSetting("global", "angle_gl_driver_selection_values"),
        )
    }

    private suspend fun lerSetting(ns: String, chave: String): String {
        val r = ShizukuManager.executar("settings get $ns $chave", 5_000L)
        return if (r.ok) r.saida.trim() else "null"
    }

    private suspend fun aplicarHz(hz: Int) {
        if (hz !in setOf(60, 90, 120)) return
        ShizukuManager.executar(
            "settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz",
            5_000L,
        )
    }

    private suspend fun aplicarAnim(escala: String) {
        if (escala !in setOf("0", "0.5", "1")) return
        ShizukuManager.executar(
            "settings put global window_animation_scale $escala; " +
                "settings put global transition_animation_scale $escala; " +
                "settings put global animator_duration_scale $escala",
            5_000L,
        )
    }

    private suspend fun aplicarDriver(pacote: String, nivel: Int, gravado: SnapPartida) {
        if (!pacoteValido(pacote) || nivel !in 0..2) return
        porLista("game_driver_opt_in_apps", pacote, nivel >= 1)
        porLista("game_driver_opt_out_apps", pacote, nivel == 0)
        val angulo = valorAngle(nivel)
        val pacotes = partirLista(gravado.anglePkgs).toMutableList()
        val valores = partirLista(gravado.angleVals).toMutableList()
        val mapa = LinkedHashMap<String, String>()
        for (i in pacotes.indices) {
            val p = pacotes[i]
            val v = valores.getOrNull(i) ?: continue
            if (pacoteValido(p) && v in setOf("default", "native", "angle")) mapa[p] = v
        }
        mapa[pacote] = angulo
        escreverGlobal("angle_gl_driver_selection_pkgs", mapa.keys.joinToString(","))
        escreverGlobal("angle_gl_driver_selection_values", mapa.values.joinToString(","))
    }

    private suspend fun porLista(chave: String, pacote: String, incluir: Boolean) {
        val atual = partirLista(lerSetting("global", chave)).filter { pacoteValido(it) }.toMutableList()
        atual.remove(pacote)
        if (incluir) atual.add(pacote)
        escreverGlobal(chave, atual.joinToString(","))
    }

    private suspend fun escreverGlobal(chave: String, valor: String) {
        if (!chave.matches(Regex("^[a-z0-9_]{1,64}$"))) return
        if (valor.isBlank()) {
            ShizukuManager.executar("settings delete global $chave", 5_000L)
            return
        }
        if (valor.length > 3500 || !valor.matches(Regex("^[A-Za-z0-9_.,]+$"))) return
        ShizukuManager.executar("settings put global $chave $valor", 5_000L)
    }

    private suspend fun restaurarLista(chave: String, original: String) {
        val partes = partirLista(original)
        val ok = partes.all { pacoteValido(it) || it in setOf("default", "native", "angle") }
        if (!ok) return
        escreverGlobal(chave, partes.joinToString(","))
    }

    private suspend fun medirPing(): Int? {
        val r = ShizukuManager.executar("ping -c 1 -W 1 1.1.1.1", 4_000L)
        val m = Regex("""time=([0-9.]+)""").find(r.saida) ?: return null
        return m.groupValues[1].toFloatOrNull()?.toInt()
    }

    private suspend fun aplicarTela(fatorNovo: Float, largura: Int, altura: Int) {
        val texto = escalarTela(largura, altura, fatorNovo)
        if (!texto.matches(Regex("^[0-9]{3,5}x[0-9]{3,5}$"))) return
        ShizukuManager.executar("wm size $texto", 5_000L)
    }

    private suspend fun travarFundo(gravado: SnapPartida) {
        for (pacote in gravado.buckets.keys) {
            if (!pacoteValido(pacote) || pacote == "com.discord") continue
            ShizukuManager.executar("am set-standby-bucket $pacote restricted", 5_000L)
        }
    }

    private suspend fun governar(gravado: SnapPartida) {
        val bat = ShizukuManager.executar("dumpsys battery", 5_000L)
        val bruto = bat.saida.lines().firstOrNull { it.trim().startsWith("temperature:") }
        val decimos = bruto?.substringAfter(":")?.trim()?.toIntOrNull()
        val temp = decimos?.let { it / 10f }
        if (temp != null && temp > picoTemp) picoTemp = temp
        val ping = medirPing()
        if (ping != null) {
            somaPing += ping
            nPing += 1
            if (ping >= 80) picosPing += 1
        }
        var hz = _partida.value.hz
        var nota = _partida.value.nota
        if (temp != null && temp >= 41f && driverAtual > 0 && pacoteValido(pacoteJogo)) {
            driverAtual -= 1
            aplicarDriver(pacoteJogo, driverAtual, gravado)
            cortes += 1
            folga = 0
            nota = "Calor em ${"%.0f".format(temp)}°. Driver foi para ${nomeDriver(driverAtual)}."
        } else if (temp != null && temp >= 44f && hz > 60) {
            hz = if (hz >= 120) 90 else 60
            aplicarHz(hz)
            cortes += 1
            folga = 0
            nota = "Calor em ${"%.0f".format(temp)}°. Hz foi para $hz."
        } else if (temp != null && temp >= 42f && fator > 0.72f) {
            fator = (fator - 0.08f).coerceAtLeast(0.70f)
            aplicarTela(fator, gravado.largura, gravado.altura)
            cortes += 1
            folga = 0
            nota = "Calor em ${"%.0f".format(temp)}°. Tela foi para ${(fator * 100).toInt()}%."
        } else if (temp != null && temp < 36f) {
            folga += 1
            if (folga >= 3 && (driverAtual < alvoDriver || hz < alvoHz || fator < alvoRes - 0.02f)) {
                if (driverAtual < alvoDriver && pacoteValido(pacoteJogo)) {
                    driverAtual += 1
                    aplicarDriver(pacoteJogo, driverAtual, gravado)
                    nota = "Folga térmica. Driver voltou a ${nomeDriver(driverAtual)}."
                } else if (hz < alvoHz) {
                    hz = if (hz <= 60) minOf(90, alvoHz) else alvoHz
                    aplicarHz(hz)
                    nota = "Folga térmica. Hz voltou a $hz."
                } else {
                    fator = minOf(alvoRes, fator + 0.08f)
                    if (fator >= 0.98f) {
                        ShizukuManager.executar("wm size reset", 5_000L)
                    } else {
                        aplicarTela(fator, gravado.largura, gravado.altura)
                    }
                    nota = "Folga térmica. Tela voltou a ${(fator * 100).toInt()}%."
                }
                folga = 0
            }
        } else {
            folga = 0
        }
        _partida.value = _partida.value.copy(
            hz = hz,
            temp = temp ?: _partida.value.temp,
            nota = nota,
            driver = driverAtual,
            ping = ping ?: _partida.value.ping,
        )
        espelharBolha()
    }

    private suspend fun restaurar(gravado: SnapPartida) {
        ShizukuManager.executar(settingRestaura("system", "peak_refresh_rate", gravado.peak), 5_000L)
        ShizukuManager.executar(settingRestaura("system", "min_refresh_rate", gravado.minHz), 5_000L)
        ShizukuManager.executar(settingRestaura("global", "window_animation_scale", gravado.animWin), 5_000L)
        ShizukuManager.executar(settingRestaura("global", "transition_animation_scale", gravado.animTrans), 5_000L)
        ShizukuManager.executar(settingRestaura("global", "animator_duration_scale", gravado.animDur), 5_000L)
        ShizukuManager.executar(settingRestaura("global", "low_power", gravado.lowPower), 5_000L)
        ShizukuManager.executar("wm size reset", 5_000L)
        restaurarLista("game_driver_opt_in_apps", gravado.gameOptIn)
        restaurarLista("game_driver_opt_out_apps", gravado.gameOptOut)
        restaurarLista("angle_gl_driver_selection_pkgs", gravado.anglePkgs)
        restaurarLista("angle_gl_driver_selection_values", gravado.angleVals)
        for ((pacote, bucket) in gravado.buckets) {
            if (!pacoteValido(pacote) || !bucket.matches(Regex("^[a-z0-9_]{1,20}$"))) continue
            ShizukuManager.executar("am set-standby-bucket $pacote $bucket", 5_000L)
        }
    }

    private fun settingRestaura(ns: String, chave: String, valor: String): String {
        val v = valor.trim()
        return if (v.isBlank() || v == "null") {
            "settings delete $ns $chave"
        } else if (v.matches(Regex("^[0-9.]+$"))) {
            "settings put $ns $chave $v"
        } else {
            "settings delete $ns $chave"
        }
    }
}

private data class SnapPartida(
    val peak: String,
    val minHz: String,
    val animWin: String,
    val animTrans: String,
    val animDur: String,
    val lowPower: String,
    val buckets: Map<String, String>,
    val largura: Int,
    val altura: Int,
    val gameOptIn: String,
    val gameOptOut: String,
    val anglePkgs: String,
    val angleVals: String,
)
