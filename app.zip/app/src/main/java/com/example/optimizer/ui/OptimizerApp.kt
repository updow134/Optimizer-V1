package com.example.optimizer.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.optimizer.R
import kotlinx.coroutines.flow.collectLatest

private const val ABA_MONITOR: Int = 1

private data class Aba(val nome: String, val icone: @Composable () -> Unit)

private val ABAS: List<Aba> = listOf(
    Aba("Início") { Icon(Icons.Default.Home, contentDescription = null) },
    Aba("Monitor") {
        Icon(painterResource(R.drawable.ic_monitor), contentDescription = null)
    },
    Aba("Hub") { Icon(Icons.Default.Star, contentDescription = null) },
    Aba("Ferramentas") { Icon(Icons.Default.Build, contentDescription = null) },
    Aba("Ajustes") { Icon(Icons.Default.Settings, contentDescription = null) },
)

private fun corCategoria(categoria: String): Color = when (categoria) {
    "Rápidas" -> Neon.Ciano
    "Tela" -> Neon.Violeta
    "Apps" -> Neon.Verde
    "Sistema" -> Neon.Ambar
    else -> Neon.Rosa
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptimizerApp(vm: OptimizerViewModel = viewModel()) {
    TemaOptimizer {
        val estado by vm.estado.collectAsStateWithLifecycle()
        val ocupado by vm.ocupado.collectAsStateWithLifecycle()
        val saida by vm.saida.collectAsStateWithLifecycle()
        val reversao by vm.reversao.collectAsStateWithLifecycle()
        val historico by vm.historico.collectAsStateWithLifecycle()

        val snack = remember { SnackbarHostState() }
        var aba by rememberSaveable { mutableIntStateOf(0) }
        var dialogoIdx by rememberSaveable { mutableIntStateOf(-1) }
        var primeiroPlano by remember { mutableStateOf(true) }
        val ferramentaDialogo: Ferramenta? = FERRAMENTAS.getOrNull(dialogoIdx)
        val conectado = estado == ShizukuState.CONECTADO

        LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.atualizar() }
        LifecycleEventEffect(Lifecycle.Event.ON_START) { primeiroPlano = true }
        LifecycleEventEffect(Lifecycle.Event.ON_STOP) { primeiroPlano = false }
        LaunchedEffect(Unit) {
            vm.mensagens.collectLatest { texto -> snack.showSnackbar(texto) }
        }
        // O monitor só amostra com a aba aberta, o app visível e o Shizuku ativo.
        LaunchedEffect(aba, conectado, primeiroPlano) {
            if (aba == ABA_MONITOR && conectado && primeiroPlano) {
                vm.coletarAmostras()
            }
        }

        val abrir: (Ferramenta) -> Unit = { f ->
            if (f.campos.isEmpty() && f.aviso == null) {
                vm.executar(f, emptyList())
            } else {
                dialogoIdx = FERRAMENTAS.indexOf(f)
            }
        }

        Scaffold(
            containerColor = Neon.Fundo,
            topBar = { TopAppBar(title = { TituloTech(conectado) }) },
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                NavigationBar(containerColor = Neon.Superficie) {
                    ABAS.forEachIndexed { i, item ->
                        NavigationBarItem(
                            selected = aba == i,
                            onClick = { aba = i },
                            icon = { item.icone() },
                            label = { Text(item.nome) },
                        )
                    }
                }
            },
        ) { padding ->
            Column(
                Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(listOf(Color(0xFF0A1226), Neon.Fundo))
                    ),
            ) {
                if (ocupado) LinearProgressIndicator(Modifier.fillMaxWidth())
                when (aba) {
                    0 -> GradeFerramentas(
                        ferramentas = FERRAMENTAS.filter { it.categoria == "Rápidas" },
                        estado = estado,
                        mostrarStatus = true,
                        onPermitir = vm::pedirPermissao,
                        onAbrir = abrir,
                        modifier = Modifier.weight(1f),
                    )
                    1 -> MonitorScreen(
                        historico = historico,
                        conectado = conectado,
                        modifier = Modifier.weight(1f),
                    )
                    2 -> HubScreen(
                        vm = vm,
                        conectado = conectado,
                        modifier = Modifier.weight(1f),
                    )
                    3 -> GradeFerramentas(
                        ferramentas = FERRAMENTAS,
                        estado = estado,
                        mostrarStatus = false,
                        onPermitir = vm::pedirPermissao,
                        onAbrir = abrir,
                        modifier = Modifier.weight(1f),
                    )
                    else -> AjustesScreen(
                        estado = estado,
                        onPermitir = vm::pedirPermissao,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        ferramentaDialogo?.let { f ->
            FerramentaDialog(
                f = f,
                onConfirmar = { valores ->
                    dialogoIdx = -1
                    vm.executar(f, valores)
                },
                onFechar = { dialogoIdx = -1 },
            )
        }
        saida?.let { s -> SaidaDialog(s, vm::fecharSaida) }
        reversao?.let { r -> ReversaoDialog(r, onManter = vm::manter, onReverter = vm::reverter) }
    }
}

@Composable
fun TituloTech(conectado: Boolean) {
    val transicao = rememberInfiniteTransition(label = "pulso")
    val brilho by transicao.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "brilho",
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(10.dp)
                .alpha(brilho)
                .background(if (conectado) Neon.Verde else Neon.Rosa, CircleShape)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            "OPTIMIZER",
            fontWeight = FontWeight.Black,
            letterSpacing = 4.sp,
            color = MaterialTheme.colorScheme.primary,
        )
    }
}

@Composable
fun GradeFerramentas(
    ferramentas: List<Ferramenta>,
    estado: ShizukuState,
    mostrarStatus: Boolean,
    onPermitir: () -> Unit,
    onAbrir: (Ferramenta) -> Unit,
    modifier: Modifier = Modifier,
) {
    val habilitada = estado == ShizukuState.CONECTADO
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (mostrarStatus) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                ShizukuCard(estado, onPermitir)
            }
        }
        ferramentas.groupBy { it.categoria }.forEach { (categoria, lista) ->
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    categoria.uppercase(),
                    style = MaterialTheme.typography.labelLarge,
                    letterSpacing = 3.sp,
                    color = corCategoria(categoria),
                )
            }
            items(lista, key = { it.nome }) { f ->
                FerramentaCard(f, habilitada) { onAbrir(f) }
            }
        }
    }
}

@Composable
fun AjustesScreen(
    estado: ShizukuState,
    onPermitir: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        ShizukuCard(estado, onPermitir)
        Text("Como ativar o Shizuku", style = MaterialTheme.typography.titleMedium)
        Text(
            "1. Instale o app Shizuku.\n" +
                "2. Ative as Opções do desenvolvedor e a Depuração sem fio.\n" +
                "3. No Shizuku, faça o pareamento e toque em Iniciar.\n" +
                "4. Volte aqui e toque em Permitir.",
            style = MaterialTheme.typography.bodyMedium,
        )
        Text(
            "Sem root, o Shizuku para quando o aparelho reinicia. Basta iniciá-lo de novo.",
            style = MaterialTheme.typography.bodySmall,
        )
        Text("Optimizer 2.0", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun ShizukuCard(estado: ShizukuState, onPermitir: () -> Unit) {
    val ok = estado == ShizukuState.CONECTADO
    val cor = if (ok) Neon.Verde else Neon.Rosa
    Row(
        Modifier.fillMaxWidth().painelTech(cor).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = if (ok) Icons.Default.Check else Icons.Default.Warning,
            contentDescription = null,
            tint = cor,
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(estado.titulo, fontWeight = FontWeight.Bold, color = cor)
            Text(estado.detalhe, style = MaterialTheme.typography.bodySmall)
        }
        if (estado == ShizukuState.SEM_PERMISSAO) {
            Button(onClick = onPermitir) { Text("Permitir") }
        }
    }
}

@Composable
fun FerramentaCard(f: Ferramenta, habilitada: Boolean, onClick: () -> Unit) {
    val cor = corCategoria(f.categoria)
    Column(
        Modifier
            .fillMaxWidth()
            .alpha(if (habilitada) 1f else 0.4f)
            .painelTech(cor)
            .clickable(enabled = habilitada, onClick = onClick)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            Modifier.size(40.dp).background(cor.copy(alpha = 0.15f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(f.icone, contentDescription = null, tint = cor)
        }
        Text(f.nome, fontWeight = FontWeight.SemiBold)
        Text(
            f.descricao,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun FerramentaDialog(f: Ferramenta, onConfirmar: (List<String>) -> Unit, onFechar: () -> Unit) {
    val valores = remember(f.nome) {
        mutableStateListOf<String>().apply { repeat(f.campos.size) { add("") } }
    }
    val preenchido = valores.all { it.isNotEmpty() }
    val erro: String? = if (preenchido) validarCampos(f, valores.toList()) else null

    AlertDialog(
        onDismissRequest = onFechar,
        title = { Text(f.nome) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                val aviso = f.aviso
                if (aviso != null) {
                    Text(
                        aviso,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                f.campos.forEachIndexed { i, campo ->
                    val atual = valores[i]
                    OutlinedTextField(
                        value = atual,
                        onValueChange = { novo -> valores[i] = novo.trim() },
                        label = { Text(campo.rotulo) },
                        supportingText = { Text(campo.tipo.dica) },
                        isError = atual.isNotEmpty() && !campo.tipo.regex.matches(atual),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = if (campo.tipo == TipoCampo.NUMERO) {
                                KeyboardType.Number
                            } else {
                                KeyboardType.Text
                            }
                        ),
                    )
                }
                if (erro != null) {
                    Text(
                        erro,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirmar(valores.toList()) },
                enabled = preenchido && erro == null,
            ) { Text("Aplicar") }
        },
        dismissButton = { TextButton(onClick = onFechar) { Text("Cancelar") } },
    )
}

@Composable
fun SaidaDialog(saida: Saida, onFechar: () -> Unit) {
    AlertDialog(
        onDismissRequest = onFechar,
        title = { Text(saida.titulo) },
        text = {
            Text(
                saida.texto.ifBlank { "Sem saída" },
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                modifier = Modifier
                    .heightIn(max = 360.dp)
                    .verticalScroll(rememberScrollState()),
            )
        },
        confirmButton = { TextButton(onClick = onFechar) { Text("Fechar") } },
    )
}

@Composable
fun ReversaoDialog(r: Reversao, onManter: () -> Unit, onReverter: () -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Manter alterações?") },
        text = { Text("Revertendo automaticamente em ${r.segundos}s.") },
        confirmButton = { TextButton(onClick = onManter) { Text("Manter") } },
        dismissButton = { TextButton(onClick = onReverter) { Text("Reverter") } },
    )
}
