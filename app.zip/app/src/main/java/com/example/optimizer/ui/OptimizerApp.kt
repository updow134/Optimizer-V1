package com.example.optimizer.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.optimizer.R
import kotlinx.coroutines.flow.collectLatest

private const val ABA_MONITOR: Int = 1

private data class Aba(val nome: String, val icone: @Composable () -> Unit)

private val ABAS: List<Aba> = listOf(
    Aba("Início") { Icon(Icons.Default.Home, contentDescription = null) },
    Aba("Monitor") {
        Icon(painterResource(R.drawable.ic_monitor), contentDescription = null)
    },
    Aba("Gaming") { Icon(Icons.Default.Star, contentDescription = null) },
    Aba("Ferramentas") { Icon(Icons.Default.Build, contentDescription = null) },
    Aba("Ajustes") { Icon(Icons.Default.Settings, contentDescription = null) },
)

private fun corCategoria(categoria: String): Color = when (categoria) {
    "Rápidas" -> Neon.Ciano
    "Tela" -> Neon.Violeta
    "Apps" -> Neon.Verde
    "Sistema" -> Neon.Ambar
    else -> Neon.Rosa
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptimizerApp(vm: OptimizerViewModel = viewModel()) {
    TemaOptimizer {
        val contexto = LocalContext.current
        var aceitou by remember { mutableStateOf(termosAceitos(contexto)) }
        if (!aceitou) {
            TermosScreen(aoAceitar = {
                aceitarTermos(contexto)
                aceitou = true
                vm.segurarFundo()
            })
            return@TemaOptimizer
        }
        LaunchedEffect(Unit) { vm.segurarFundo() }
        val estado by vm.estado.collectAsStateWithLifecycle()
        val ocupado by vm.ocupado.collectAsStateWithLifecycle()
        val saida by vm.saida.collectAsStateWithLifecycle()
        val reversao by vm.reversao.collectAsStateWithLifecycle()
        val historico by vm.historico.collectAsStateWithLifecycle()
        val perfil by vm.perfil.collectAsStateWithLifecycle()
        val guard by vm.guard.collectAsStateWithLifecycle()
        val snapPendente by vm.snapPendente.collectAsStateWithLifecycle()
        val diagTick by vm.diagTick.collectAsStateWithLifecycle()

        val snack = remember { SnackbarHostState() }
        var aba by rememberSaveable { mutableIntStateOf(0) }
        var dialogoIdx by rememberSaveable { mutableIntStateOf(-1) }
        var verTermos by remember { mutableStateOf(false) }
        var primeiroPlano by remember { mutableStateOf(true) }
        val ferramentaDialogo: Ferramenta? = FERRAMENTAS.getOrNull(dialogoIdx)
        val conectado = estado == ShizukuState.CONECTADO

        LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.atualizar() }
        LifecycleEventEffect(Lifecycle.Event.ON_START) { primeiroPlano = true }
        LifecycleEventEffect(Lifecycle.Event.ON_STOP) { primeiroPlano = false }
        LaunchedEffect(Unit) {
            vm.mensagens.collectLatest { texto -> snack.showSnackbar(texto) }
        }
        // O monitor só amostra com a aba aberta, o app visível e o Shizuku ativo.
        LaunchedEffect(aba, conectado, primeiroPlano) {
            if ((aba == 0 || aba == ABA_MONITOR) && conectado && primeiroPlano) {
                vm.coletarAmostras()
            }
        }

        val abrir: (Ferramenta) -> Unit = { f ->
            val direto = f.campos.isEmpty() && f.aviso == null && f.nome != "Processos pesados"
            if (direto) {
                vm.executar(f, emptyList())
            } else {
                dialogoIdx = FERRAMENTAS.indexOf(f)
            }
        }

        Scaffold(
            containerColor = Neon.Fundo,
            topBar = { TopAppBar(title = { TituloTech(conectado) }) },
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                NavigationBar(containerColor = Neon.Superficie) {
                    ABAS.forEachIndexed { i, item ->
                        NavigationBarItem(
                            selected = aba == i,
                            onClick = { aba = i },
                            icon = { item.icone() },
                            label = { Text(item.nome) },
                        )
                    }
                }
            },
        ) { padding ->
            Column(
                Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(listOf(Color(0xFF0A1226), Neon.Fundo))
                    ),
            ) {
                if (ocupado) LinearProgressIndicator(Modifier.fillMaxWidth())
                when (aba) {
                    0 -> InicioScreen(
                        historico = historico,
                        conectado = conectado,
                        perfil = perfil,
                        jogos = vm.jogosRecentes(),
                        onPerfil = vm::aplicarPerfil,
                        onOtimizar = {
                            FERRAMENTAS.firstOrNull { it.nome == "Limpar RAM" }?.let { abrir(it) }
                        },
                        onFerramenta = { nome ->
                            val f = FERRAMENTAS.firstOrNull { it.nome == nome } ?: return@InicioScreen
                            abrir(f)
                        },
                        onGaming = { aba = 2 },
                        pendentes = guard.filter { it.ok && it.temporario && !it.restaurado && it.comandoRestaurar.isNotBlank() },
                        snapPendente = snapPendente,
                        recomendacoes = vm.recomendacoes().let { if (diagTick >= 0) it else it },
                        onRestaurar = vm::restaurarRegistro,
                        onRestaurarTudo = vm::restaurarPendentes,
                        onRestaurarPartida = vm::restaurarPartidaInterrompida,
                        onAplicarRec = vm::aplicarRecomendacao,
                        onIgnorarRec = vm::ignorarRecomendacao,
                        modifier = Modifier.weight(1f),
                    )
                    1 -> MonitorScreen(
                        historico = historico,
                        conectado = conectado,
                        modifier = Modifier.weight(1f),
                    )
                    2 -> HubScreen(
                        vm = vm,
                        conectado = conectado,
                        modifier = Modifier.weight(1f),
                    )
                    3 -> GradeFerramentas(
                        ferramentas = FERRAMENTAS,
                        estado = estado,
                        mostrarStatus = false,
                        onPermitir = vm::pedirPermissao,
                        onAbrir = abrir,
                        modifier = Modifier.weight(1f),
                    )
                    else -> AjustesScreen(
                        estado = estado,
                        vm = vm,
                        onPermitir = vm::pedirPermissao,
                        onTermos = { verTermos = true },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        ferramentaDialogo?.let { f ->
            FerramentaDialog(
                f = f,
                vm = vm,
                onConfirmar = { valores ->
                    dialogoIdx = -1
                    vm.executar(f, valores)
                },
                onFechar = { dialogoIdx = -1 },
            )
        }
        saida?.let { s -> SaidaDialog(s, vm::fecharSaida) }
        reversao?.let { r -> ReversaoDialog(r, onManter = vm::manter, onReverter = vm::reverter) }
        if (verTermos) {
            AlertDialog(
                onDismissRequest = { verTermos = false },
                title = { Text("Termos de uso") },
                text = {
                    Text(
                        TEXTO_TERMOS,
                        modifier = Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                    )
                },
                confirmButton = { TextButton(onClick = { verTermos = false }) { Text("Fechar") } },
            )
        }
    }
}

@Composable
fun TituloTech(conectado: Boolean) {
    val transicao = rememberInfiniteTransition(label = "pulso")
    val brilho by transicao.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "brilho",
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(10.dp)
                .alpha(brilho)
                .background(if (conectado) Neon.Verde else Neon.Rosa, CircleShape)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            "OPTIMIZER",
            fontWeight = FontWeight.Black,
            letterSpacing = 4.sp,
            color = MaterialTheme.colorScheme.primary,
        )
    }
}

@Composable
fun GradeFerramentas(
    ferramentas: List<Ferramenta>,
    estado: ShizukuState,
    mostrarStatus: Boolean,
    onPermitir: () -> Unit,
    onAbrir: (Ferramenta) -> Unit,
    modifier: Modifier = Modifier,
) {
    val habilitada = estado == ShizukuState.CONECTADO
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (mostrarStatus) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                ShizukuCard(estado, onPermitir)
            }
        }
        ferramentas.groupBy { it.categoria }.forEach { (categoria, lista) ->
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    categoria.let { rotuloCategoria(it) }.uppercase(),
                    style = MaterialTheme.typography.labelLarge,
                    letterSpacing = 3.sp,
                    color = corCategoria(categoria),
                )
            }
            items(lista, key = { it.nome }) { f ->
                FerramentaCard(f, habilitada) { onAbrir(f) }
            }
        }
    }
}

@Composable
fun AjustesScreen(
    estado: ShizukuState,
    vm: OptimizerViewModel,
    onPermitir: () -> Unit,
    onTermos: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val perfis by vm.perfis.collectAsStateWithLifecycle()
    var nomeCopia by remember { mutableStateOf("") }
    Column(
        modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Shizuku", fontWeight = FontWeight.SemiBold, color = Neon.Ciano)
        ShizukuCard(estado, onPermitir)
        Text(
            "1. Instale o Shizuku.\n2. Ative a depuração sem fio.\n3. Inicie o Shizuku.\n4. Toque em Permitir aqui.\nSem root, ele para quando o celular reinicia.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        BlocoAjuste("Monitoramento", "A leitura de CPU, RAM, calor e bateria acontece com o app aberto em Início ou Monitor. Nada disso sai do aparelho.")
        Text("Perfis", fontWeight = FontWeight.SemiBold, color = Neon.Ciano)
        Text(vm.textoGuard().ifBlank { "O Guard ainda não registrou alteração." }, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(
            value = nomeCopia,
            onValueChange = { nomeCopia = it.take(24) },
            label = { Text("Nome da cópia") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Button(
            onClick = {
                val id = nomeCopia.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
                if (id.length >= 2) vm.duplicarPerfilAtual(id, nomeCopia)
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Duplicar o perfil ativo") }
        perfis.filter { !it.fixo }.forEach { p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(p.nome, modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.excluirPerfilSalvo(p.id) }) { Text("Excluir") }
            }
        }
        TextButton(onClick = vm::restaurarPerfisOriginais) { Text("Restaurar perfis originais") }
        BlocoAjuste("Segurança", "Resolução e DPI voltam em 10 segundos se você não tocar em Manter. Apps do sistema não entram em congelar, parar ou permissão.")
        BlocoAjuste("Privacidade", "Não há conta, anúncio nem servidor. O app não envia leitura para fora. CPU, RAM, calor, bateria, lista de apps e os ajustes ficam neste celular, em arquivos do próprio Optimizer. A bolha usa a permissão de desenhar sobre outros apps. A notificação existe porque o Android exige isso de um serviço que fica ligado. O Shizuku é o que permite ler e mudar a tela. Nada disso é vendido ou compartilhado. Apagar o app apaga o histórico do Guard, os perfis criados e a lista de jogos.")
        BlocoAjuste("Permissões", "Desenhar sobre outros apps: a bolha da Lucy. Notificação: o serviço não ser morto. Iniciar com o celular: voltar a limpar a RAM se você aceitou os termos. Shizuku: os comandos de tela, driver e processo. Sem essas permissões a parte correspondente não roda.")
        BlocoAjuste("Como desfazer", "Resolução e DPI voltam em 10 segundos se você não tocar em Manter. O Guard guarda o valor anterior. No Início, Restaurar devolve uma alteração. Se o app fechar no meio de uma partida, Devolver a tela usa o que foi gravado no começo dela. Não há desfazer silencioso.")
        BlocoAjuste("Perguntas", "O Shizuku parou depois de reiniciar: sem root isso é normal, inicie de novo. A GPU aparece como indisponível: o fabricante não deixa ler esse arquivo. Congelar some com o ícone, não apaga o app. Permissão recusada: o Android não entrega aquela permissão para aquele pacote.")
        Button(onClick = onTermos, modifier = Modifier.fillMaxWidth()) { Text("Termos de uso") }
        BlocoAjuste("Sobre", "Optimizer 4.0. Otimiza tela, memória e jogos pelo Shizuku. A Lucy acompanha a partida numa bolha.")
        BlocoAjuste(
            "Versões",
            "3.5 bolha e termos. 3.6 correção de compilação. 3.7 listas com ícone. 4.0 início, monitor e gaming no mesmo visual.",
        )
        BlocoAjuste("Suporte", "Se uma ferramenta falhar, confira se o Shizuku está iniciado e se a permissão deste app continua válida.")
    }
}

@Composable
private fun BlocoAjuste(titulo: String, texto: String) {
    Column(Modifier.fillMaxWidth().painelTech().padding(14.dp)) {
        Text(titulo, fontWeight = FontWeight.Medium)
        Text(texto, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun rotuloCategoria(categoria: String): String = when (categoria) {
    "Rápidas" -> "Desempenho e limpeza"
    "Tela" -> "Tela, DPI e Hz"
    "Apps" -> "Apps, processos e permissões"
    "Sistema" -> "Sistema"
    "Info" -> "Diagnóstico"
    else -> categoria
}

@Composable
fun ShizukuCard(estado: ShizukuState, onPermitir: () -> Unit) {
    val ok = estado == ShizukuState.CONECTADO
    val cor = if (ok) Neon.Verde else Neon.Rosa
    Row(
        Modifier.fillMaxWidth().painelTech(cor).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = if (ok) Icons.Default.Check else Icons.Default.Warning,
            contentDescription = null,
            tint = cor,
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(estado.titulo, fontWeight = FontWeight.Bold, color = cor)
            Text(estado.detalhe, style = MaterialTheme.typography.bodySmall)
        }
        if (estado == ShizukuState.SEM_PERMISSAO) {
            Button(onClick = onPermitir) { Text("Permitir") }
        }
    }
}

@Composable
fun FerramentaCard(f: Ferramenta, habilitada: Boolean, onClick: () -> Unit) {
    val cor = corCategoria(f.categoria)
    Column(
        Modifier
            .fillMaxWidth()
            .alpha(if (habilitada) 1f else 0.4f)
            .painelTech(cor)
            .clickable(enabled = habilitada, onClick = onClick)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            Modifier.size(40.dp).background(cor.copy(alpha = 0.15f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(f.icone, contentDescription = null, tint = cor)
        }
        Text(f.nome, fontWeight = FontWeight.SemiBold)
        Text(
            f.descricao,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun FerramentaDialog(
    f: Ferramenta,
    vm: OptimizerViewModel,
    onConfirmar: (List<String>) -> Unit,
    onFechar: () -> Unit,
) {
    when (f.nome) {
        "Resolução" -> PainelResolucao(onAplicar = { onConfirmar(listOf(it)) }, onFechar = onFechar)
        "Processos pesados", "Forçar parada" -> PainelProcessos(vm, onFechar)
        "Congelar app" -> PainelCongelar(vm, soCongelados = false, onFechar = onFechar)
        "Descongelar app" -> PainelCongelar(vm, soCongelados = true, onFechar = onFechar)
        "Permissões" -> PainelPermissoes(vm, onFechar)
        else -> DialogoCampos(f, onConfirmar, onFechar)
    }
}

@Composable
private fun DialogoCampos(f: Ferramenta, onConfirmar: (List<String>) -> Unit, onFechar: () -> Unit) {
    val soEscolha = f.campos.size == 1 && f.campos[0].opcoes.isNotEmpty()
    var ciente by remember(f.nome) { mutableStateOf(false) }
    if (soEscolha) {
        val campo = f.campos[0]
        PainelCheio(f.nome, onFechar) {
            val aviso = f.aviso
            if (aviso != null) {
                Text(aviso, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (f.exigeConfirmar && !ciente) {
                Button(onClick = { ciente = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Entendi o risco")
                }
            }
            Column(Modifier.verticalScroll(rememberScrollState()).padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                campo.opcoes.forEach { (rotulo, valor) ->
                    Button(
                        onClick = { onConfirmar(listOf(valor)) },
                        enabled = !f.exigeConfirmar || ciente,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text(rotulo) }
                }
            }
        }
        return
    }
    val valores = remember(f.nome) {
        mutableStateListOf<String>().apply { repeat(f.campos.size) { add("") } }
    }
    val preenchido = valores.all { it.isNotEmpty() }
    val erro: String? = if (preenchido) validarCampos(f, valores.toList()) else null

    AlertDialog(
        onDismissRequest = onFechar,
        title = { Text(f.nome) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                val aviso = f.aviso
                if (aviso != null) {
                    Text(
                        aviso,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                f.campos.forEachIndexed { i, campo ->
                    if (campo.opcoes.isNotEmpty()) {
                        Text(campo.rotulo)
                        campo.opcoes.forEach { (rotulo, valor) ->
                            if (valores[i] == valor) {
                                Button(onClick = { valores[i] = valor }, modifier = Modifier.fillMaxWidth()) { Text(rotulo) }
                            } else {
                                OutlinedButton(onClick = { valores[i] = valor }, modifier = Modifier.fillMaxWidth()) { Text(rotulo) }
                            }
                        }
                    } else {
                        val atual = valores[i]
                        OutlinedTextField(
                            value = atual,
                            onValueChange = { novo -> valores[i] = novo.trim() },
                            label = { Text(campo.rotulo) },
                            supportingText = { Text(campo.tipo.dica) },
                            isError = atual.isNotEmpty() && !campo.tipo.regex.matches(atual),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = if (campo.tipo == TipoCampo.NUMERO) {
                                    KeyboardType.Number
                                } else {
                                    KeyboardType.Text
                                }
                            ),
                        )
                    }
                }
                if (erro != null) {
                    Text(
                        erro,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirmar(valores.toList()) },
                enabled = preenchido && erro == null && (!f.exigeConfirmar || ciente),
            ) { Text("Aplicar") }
        },
        dismissButton = { TextButton(onClick = onFechar) { Text("Cancelar") } },
    )
}

@Composable
fun SaidaDialog(saida: Saida, onFechar: () -> Unit) {
    AlertDialog(
        onDismissRequest = onFechar,
        title = { Text(saida.titulo) },
        text = {
            Text(
                saida.texto.ifBlank { "Sem saída" },
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                modifier = Modifier
                    .heightIn(max = 360.dp)
                    .verticalScroll(rememberScrollState()),
            )
        },
        confirmButton = { TextButton(onClick = onFechar) { Text("Fechar") } },
    )
}

@Composable
fun ReversaoDialog(r: Reversao, onManter: () -> Unit, onReverter: () -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Ficou boa?") },
        text = { Text("A tela volta ao normal em ${r.segundos} segundos. Toque em Manter se quiser ficar assim.") },
        confirmButton = { TextButton(onClick = onManter) { Text("Manter") } },
        dismissButton = { TextButton(onClick = onReverter) { Text("Reverter") } },
    )
}
