package com.example.optimizer.ui

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.provider.Settings
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.optimizer.MainActivity
import com.example.optimizer.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** O que a bolha mostra sem depender da tela do app estar aberta. */
object PonteLucy {
    @Volatile var hz: Int = 0
    @Volatile var driver: Int = 1
    @Volatile var ping: Int? = null
    @Volatile var nota: String = ""
    @Volatile var partida: Boolean = false
    @Volatile var aoDriver: ((Int) -> Unit)? = null
}

private data class Leitura(
    val nome: String,
    val temp: String,
    val hz: String,
    val driver: String,
    val ping: String,
    val frames: String,
)

class LucyBolhaService : Service() {
    private val escopo = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var loop: Job? = null
    private var wm: WindowManager? = null
    private var raiz: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var painel: LinearLayout? = null
    private var titulo: TextView? = null
    private var linhaA: LinearLayout? = null
    private var linhaB: LinearLayout? = null
    private var aberto = false
    private var face: ImageView? = null
    private val prefs by lazy { getSharedPreferences("lucy-bolha", MODE_PRIVATE) }
    private var tamanho = 0
    private var opacidade = 1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        criarCanal()
        val aviso = notificacao()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, aviso, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, aviso)
        }
        if (Settings.canDrawOverlays(this) && raiz == null) mostrar()
        if (loop == null) loop = escopo.launch { vigiar() }
        ligada = true
        return START_STICKY
    }

    override fun onDestroy() {
        ligada = false
        prefs.unregisterOnSharedPreferenceChangeListener(aoMudar)
        loop?.cancel()
        loop = null
        escopo.cancel()
        raiz?.let { runCatching { wm?.removeView(it) } }
        raiz = null
        super.onDestroy()
    }

    private var pulso = 0

    private suspend fun vigiar() {
        while (true) {
            val texto = withContext(Dispatchers.IO) { ler() }
            encher(texto)
            pulso += 1
            if (pulso % 12 == 0) withContext(Dispatchers.IO) { limparRam() }
            delay(5_000)
        }
    }

    private suspend fun ler(): Leitura {
        if (ShizukuManager.estado() != ShizukuState.CONECTADO) {
            return Leitura("Shizuku parado", "—", "—", "—", "—", "—")
        }
        val janela = ShizukuManager.executar("dumpsys window", 8_000L)
        val pacote = if (janela.ok) extrairFoco(janela.saida) else null
        val jogo = pacote?.let { reconhecer(it) }
        val nome = jogo?.nome ?: pacote?.substringAfterLast('.') ?: "Nenhum jogo"
        val bat = ShizukuManager.executar("dumpsys battery", 5_000L)
        val bruto = bat.saida.lines().firstOrNull { it.trim().startsWith("temperature:") }
        val temp = bruto?.substringAfter(":")?.trim()?.toIntOrNull()?.div(10f)
        val calor = temp?.let { "%.0f°".format(it) } ?: "—"
        val hz = if (PonteLucy.hz > 0) "${PonteLucy.hz} Hz" else "Hz livre"
        val ping = PonteLucy.ping?.let { "$it ms" } ?: "—"
        val frames = if (pacote != null && pacoteValido(pacote)) jankDe(pacote) else "—"
        return Leitura(nome, calor, hz, nomeDriver(PonteLucy.driver), ping, "$frames frames")
    }

    private suspend fun jankDe(pacote: String): String {
        val r = ShizukuManager.executar("dumpsys gfxinfo $pacote", 6_000L)
        if (!r.ok) return "—"
        val m = Regex("""Janky frames:\s*(\d+)\s*\(([\d.]+)%\)""").find(r.saida)
        return if (m != null) "${m.groupValues[2]}%" else "—"
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun mostrar() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tamanho = prefs.getInt("tamanho", 0).coerceIn(0, 2)
        opacidade = prefs.getInt("opacidade", 1).coerceIn(0, 2)
        val lado = dp(listOf(36, 46, 58)[tamanho])

        val rosto = ImageView(this).apply {
            setImageResource(R.drawable.lucy)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF1A0B16.toInt())
                setStroke(dp(1), 0xFFFF4081.toInt())
            }
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            layoutParams = LinearLayout.LayoutParams(lado, lado)
        }
        face = rosto

        val caixa = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            alpha = listOf(0.55f, 0.82f, 1f)[opacidade]
        }
        caixa.addView(rosto)

        titulo = texto(13f, 0xFFFFFFFF.toInt(), true)
        linhaA = fila()
        linhaB = fila()
        painel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0xF0101420.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            ).apply { marginStart = dp(6) }
            addView(titulo)
            addView(linhaA)
            addView(linhaB)
        }
        caixa.addView(painel)
        prefs.registerOnSharedPreferenceChangeListener(aoMudar)

        val tipo = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            tipo,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", dp(8))
            y = prefs.getInt("y", dp(96))
        }

        var dx = 0f
        var dy = 0f
        var origemX = 0f
        var origemY = 0f
        rosto.setOnTouchListener { _, ev ->
            val p = params ?: return@setOnTouchListener false
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx = ev.rawX - p.x
                    dy = ev.rawY - p.y
                    origemX = ev.rawX
                    origemY = ev.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (ev.rawX - dx).toInt()
                    p.y = (ev.rawY - dy).toInt()
                    wm?.updateViewLayout(caixa, p)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val arrastou = kotlin.math.abs(ev.rawX - origemX) > dp(6) ||
                        kotlin.math.abs(ev.rawY - origemY) > dp(6)
                    if (!arrastou) {
                        aberto = !aberto
                        painel?.visibility = if (aberto) View.VISIBLE else View.GONE
                    }
                    prefs.edit().putInt("x", p.x).putInt("y", p.y).apply()
                    true
                }
                else -> false
            }
        }

        wm?.addView(caixa, params)
        raiz = caixa
        aplicarVisual()
    }

    private val aoMudar = SharedPreferences.OnSharedPreferenceChangeListener { _, chave ->
        if (chave == "x" || chave == "y") return@OnSharedPreferenceChangeListener
        aplicarVisual()
    }

    private fun aplicarVisual() {
        val a = LucyPrefs.ler(this)
        val lado = dp(listOf(36, 46, 58)[a.tamanho])
        face?.layoutParams = LinearLayout.LayoutParams(lado, lado)
        raiz?.alpha = listOf(0.55f, 0.82f, 1f)[a.opacidade]
        face?.requestLayout()
    }

    private fun encher(leitura: Leitura) {
        val a = LucyPrefs.ler(this)
        titulo?.text = if (a.nome) leitura.nome else ""
        titulo?.visibility = if (a.nome) View.VISIBLE else View.GONE
        val chips = mutableListOf<String>()
        if (a.temp) chips += leitura.temp
        if (a.hz) chips += leitura.hz
        if (a.driver) chips += leitura.driver
        if (a.ping) chips += leitura.ping
        if (a.frames) chips += leitura.frames
        linhaA?.removeAllViews()
        linhaB?.removeAllViews()
        chips.forEachIndexed { i, texto ->
            val linha = if (i < 3) linhaA else linhaB
            linha?.addView(chip(texto))
        }
        val tem = a.nome || chips.isNotEmpty()
        if (!tem) {
            aberto = false
            painel?.visibility = View.GONE
        }
    }

    private fun chip(texto: String) = TextView(this).apply {
        text = texto
        setTextColor(0xFFE6EEF9.toInt())
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        setSingleLine(true)
        setPadding(dp(8), dp(4), dp(8), dp(4))
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(0xFF1C2B4A.toInt())
        }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
        ).apply { marginEnd = dp(4); topMargin = dp(4) }
    }

    private fun fila() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

    private suspend fun limparRam() {
        val a = LucyPrefs.ler(this)
        if (!a.limpeza) return
        if (ShizukuManager.estado() != ShizukuState.CONECTADO) return
        val janela = ShizukuManager.executar("dumpsys window", 8_000L)
        val foco = if (janela.ok) extrairFoco(janela.saida) else null
        val ps = ShizukuManager.executar("ps -A", 8_000L)
        if (!ps.ok) return
        val pular = HashSet<String>(a.branco)
        pular.add("com.example.optimizer")
        if (foco != null) pular.add(foco)
        val vistos = LinkedHashSet<String>()
        for (linha in ps.saida.lineSequence()) {
            val nome = linha.trim().split(Regex("\\s+")).lastOrNull() ?: continue
            val base = nome.substringBefore(":")
            if (!pacoteValido(base) || base in pular) continue
            if (PROTEGIDO.any { base == it || base.startsWith("$it.") }) continue
            vistos.add(base)
            if (vistos.size >= 24) break
        }
        for (pacote in vistos) {
            ShizukuManager.executar("am kill $pacote", 3_000L)
        }
    }

    private fun texto(sp: Float, cor: Int, umaLinha: Boolean) = TextView(this).apply {
        setTextColor(cor)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        maxLines = if (umaLinha) 1 else 3
        text = "…"
    }

    private fun criarCanal() {
        if (Build.VERSION.SDK_INT < 26) return
        val canal = NotificationChannel(CANAL, "Lucy no jogo", NotificationManager.IMPORTANCE_LOW)
        canal.setShowBadge(false)
        getSystemService(NotificationManager::class.java).createNotificationChannel(canal)
    }

    private fun notificacao(): Notification {
        val abrir = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val b = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CANAL)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return b
            .setSmallIcon(R.drawable.ic_monitor)
            .setContentTitle("Lucy está sobre o jogo")
            .setContentText("Lendo o app da frente, o calor e o driver.")
            .setContentIntent(abrir)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val CANAL = "lucy-bolha"
        const val NOTIF_ID = 41
        @Volatile var ligada: Boolean = false
    }
}

private val PROTEGIDO = listOf(
    "android",
    "com.android.systemui",
    "com.android.phone",
    "com.android.bluetooth",
    "com.android.providers",
    "com.android.settings",
    "com.google.android.gms",
    "com.google.android.gsf",
    "com.google.android.ext.services",
    "com.android.inputmethod",
    "com.samsung.android.honeyboard",
)

class BootLucy : android.content.BroadcastReceiver() {
    override fun onReceive(context: android.content.Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!termosAceitos(context)) return
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
            != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        val ligar = Intent(context, LucyBolhaService::class.java)
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(ligar) else context.startService(ligar)
    }
}

