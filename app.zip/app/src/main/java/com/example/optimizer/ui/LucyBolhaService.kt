package com.example.optimizer.ui

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.optimizer.MainActivity
import com.example.optimizer.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** O que a bolha mostra sem depender da tela do app estar aberta. */
object PonteLucy {
    @Volatile var hz: Int = 0
    @Volatile var driver: Int = 1
    @Volatile var ping: Int? = null
    @Volatile var nota: String = ""
    @Volatile var partida: Boolean = false
    @Volatile var aoDriver: ((Int) -> Unit)? = null
}

class LucyBolhaService : Service() {
    private val escopo = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var loop: Job? = null
    private var wm: WindowManager? = null
    private var raiz: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var painel: LinearLayout? = null
    private var titulo: TextView? = null
    private var detalhe: TextView? = null
    private var aberto = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        criarCanal()
        val aviso = notificacao()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, aviso, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, aviso)
        }
        if (raiz == null) mostrar()
        if (loop == null) loop = escopo.launch { vigiar() }
        ligada = true
        return START_STICKY
    }

    override fun onDestroy() {
        ligada = false
        loop?.cancel()
        loop = null
        escopo.cancel()
        raiz?.let { runCatching { wm?.removeView(it) } }
        raiz = null
        super.onDestroy()
    }

    private suspend fun vigiar() {
        while (true) {
            val texto = withContext(Dispatchers.IO) { ler() }
            titulo?.text = texto.first
            detalhe?.text = texto.second
            delay(5_000)
        }
    }

    private suspend fun ler(): Pair<String, String> {
        if (ShizukuManager.estado() != ShizukuState.CONECTADO) {
            return "Shizuku parado" to "Volte no Optimizer e permita."
        }
        val janela = ShizukuManager.executar("dumpsys window", 8_000L)
        val pacote = if (janela.ok) extrairFoco(janela.saida) else null
        val jogo = pacote?.let { reconhecer(it) }
        val nome = jogo?.nome ?: pacote?.substringAfterLast('.') ?: "Nenhum jogo na frente"
        val bat = ShizukuManager.executar("dumpsys battery", 5_000L)
        val bruto = bat.saida.lines().firstOrNull { it.trim().startsWith("temperature:") }
        val temp = bruto?.substringAfter(":")?.trim()?.toIntOrNull()?.div(10f)
        val calor = temp?.let { "%.0f°".format(it) } ?: "—"
        val hz = if (PonteLucy.hz > 0) "${PonteLucy.hz} Hz" else "Hz livre"
        val ping = PonteLucy.ping?.let { "$it ms" } ?: "ping —"
        val modo = if (PonteLucy.partida) "em partida" else "só olhando"
        val linha = "$calor · $hz · ${nomeDriver(PonteLucy.driver)} · $ping · $modo"
        val nota = PonteLucy.nota.take(80)
        return nome to if (nota.isBlank()) linha else "$linha\n$nota"
    }

    private fun mostrar() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val densidade = resources.displayMetrics.density
        fun dp(n: Int) = (n * densidade).toInt()

        val face = ImageView(this).apply {
            setImageResource(R.drawable.lucy)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF1A0B16.toInt())
                setStroke(dp(2), 0xFFFF4081.toInt())
            }
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
        }

        val caixa = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(face)
        }

        titulo = texto(14f, 0xFFFFFFFF.toInt())
        detalhe = texto(12f, 0xFFB8C4D9.toInt())
        val botoes = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val opcoes = listOf(0 to "Leve", 1 to "Estável", 2 to "Nítido")
            opcoes.forEach { (nivel, nome) ->
                addView(TextView(this@LucyBolhaService).apply {
                    text = nome
                    setTextColor(0xFF1A0B16.toInt())
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(20).toFloat()
                        setColor(if (nivel == 1) 0xFF00E5FF.toInt() else 0xFFFF4081.toInt())
                    }
                    setOnClickListener {
                        PonteLucy.driver = nivel
                        val acao = PonteLucy.aoDriver
                        if (acao != null) {
                            acao.invoke(nivel)
                        } else {
                            escopo.launch(Dispatchers.IO) {
                                val janela = ShizukuManager.executar("dumpsys window", 8_000L)
                                val pacote = if (janela.ok) extrairFoco(janela.saida) else null
                                if (pacote != null) aplicarDriverDireto(pacote, nivel)
                            }
                        }
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                    ).apply { marginEnd = dp(6) }
                })
            }
        }
        painel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(10), dp(8), dp(10), dp(4))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(0xF0141824.toInt())
            }
            addView(titulo)
            addView(detalhe)
            addView(botoes)
        }
        caixa.addView(painel)

        val tipo = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            tipo,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(180)
        }

        var dx = 0f
        var dy = 0f
        var mexeu = false
        face.setOnTouchListener { _, ev ->
            val p = params ?: return@setOnTouchListener false
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx = ev.rawX - p.x
                    dy = ev.rawY - p.y
                    mexeu = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (kotlin.math.abs(ev.rawX - dx - p.x) > dp(4)) mexeu = true
                    p.x = (ev.rawX - dx).toInt()
                    p.y = (ev.rawY - dy).toInt()
                    wm?.updateViewLayout(caixa, p)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!mexeu) {
                        aberto = !aberto
                        painel?.visibility = if (aberto) View.VISIBLE else View.GONE
                    }
                    true
                }
                else -> false
            }
        }

        wm?.addView(caixa, params)
        raiz = caixa
    }

    private fun texto(sp: Float, cor: Int) = TextView(this).apply {
        setTextColor(cor)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        text = "Lendo o jogo…"
    }

    private fun criarCanal() {
        if (Build.VERSION.SDK_INT < 26) return
        val canal = NotificationChannel(CANAL, "Lucy no jogo", NotificationManager.IMPORTANCE_LOW)
        canal.setShowBadge(false)
        getSystemService(NotificationManager::class.java).createNotificationChannel(canal)
    }

    private fun notificacao(): Notification {
        val abrir = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val b = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CANAL)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return b
            .setSmallIcon(R.drawable.ic_monitor)
            .setContentTitle("Lucy está sobre o jogo")
            .setContentText("Lendo o app da frente, o calor e o driver.")
            .setContentIntent(abrir)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val CANAL = "lucy-bolha"
        const val NOTIF_ID = 41
        @Volatile var ligada: Boolean = false
    }
}

private suspend fun aplicarDriverDireto(pacote: String, nivel: Int) {
    if (!pacoteValido(pacote) || nivel !in 0..2) return
    suspend fun lista(chave: String, incluir: Boolean) {
        val atual = partirLista(ShizukuManager.executar("settings get global $chave", 5_000L).saida)
            .filter { pacoteValido(it) }
            .toMutableList()
        atual.remove(pacote)
        if (incluir) atual.add(pacote)
        val valor = atual.joinToString(",")
        val cmd = if (valor.isBlank()) "settings delete global $chave" else "settings put global $chave $valor"
        if (valor.isBlank() || valor.matches(Regex("^[A-Za-z0-9_.,]+$"))) {
            ShizukuManager.executar(cmd, 5_000L)
        }
    }
    lista("game_driver_opt_in_apps", nivel >= 1)
    lista("game_driver_opt_out_apps", nivel == 0)
    val angulo = valorAngle(nivel)
    val pacotes = partirLista(ShizukuManager.executar("settings get global angle_gl_driver_selection_pkgs", 5_000L).saida)
    val valores = partirLista(ShizukuManager.executar("settings get global angle_gl_driver_selection_values", 5_000L).saida)
    val mapa = LinkedHashMap<String, String>()
    for (i in pacotes.indices) {
        val p = pacotes[i]
        val v = valores.getOrNull(i) ?: continue
        if (pacoteValido(p) && v in setOf("default", "native", "angle")) mapa[p] = v
    }
    mapa[pacote] = angulo
    ShizukuManager.executar(
        "settings put global angle_gl_driver_selection_pkgs ${mapa.keys.joinToString(",")}; " +
            "settings put global angle_gl_driver_selection_values ${mapa.values.joinToString(",")}",
        5_000L,
    )
}
