package com.example.optimizer.ui

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.optimizer.MainActivity
import com.example.optimizer.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** O que a bolha mostra sem depender da tela do app estar aberta. */
object PonteLucy {
    @Volatile var hz: Int = 0
    @Volatile var driver: Int = 1
    @Volatile var ping: Int? = null
    @Volatile var nota: String = ""
    @Volatile var partida: Boolean = false
    @Volatile var aoDriver: ((Int) -> Unit)? = null
}

private data class Leitura(val nome: String, val stats: String, val extra: String)

class LucyBolhaService : Service() {
    private val escopo = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var loop: Job? = null
    private var wm: WindowManager? = null
    private var raiz: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var painel: LinearLayout? = null
    private var titulo: TextView? = null
    private var detalhe: TextView? = null
    private var aberto = false
    private var face: ImageView? = null
    private var extra: TextView? = null
    private val prefs by lazy { getSharedPreferences("lucy-bolha", MODE_PRIVATE) }
    private var tamanho = 0
    private var opacidade = 1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        criarCanal()
        val aviso = notificacao()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, aviso, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, aviso)
        }
        if (raiz == null) mostrar()
        if (loop == null) loop = escopo.launch { vigiar() }
        ligada = true
        return START_STICKY
    }

    override fun onDestroy() {
        ligada = false
        loop?.cancel()
        loop = null
        escopo.cancel()
        raiz?.let { runCatching { wm?.removeView(it) } }
        raiz = null
        super.onDestroy()
    }

    private suspend fun vigiar() {
        while (true) {
            val texto = withContext(Dispatchers.IO) { ler() }
            titulo?.text = texto.nome
            detalhe?.text = texto.stats
            extra?.text = texto.extra
            delay(5_000)
        }
    }

    private suspend fun ler(): Leitura {
        if (ShizukuManager.estado() != ShizukuState.CONECTADO) {
            return Leitura("Shizuku parado", "Sem permissão", "Abra o Optimizer e permita.")
        }
        val janela = ShizukuManager.executar("dumpsys window", 8_000L)
        val pacote = if (janela.ok) extrairFoco(janela.saida) else null
        val jogo = pacote?.let { reconhecer(it) }
        val nome = jogo?.nome ?: pacote?.substringAfterLast('.') ?: "Nenhum jogo"
        val bat = ShizukuManager.executar("dumpsys battery", 5_000L)
        val bruto = bat.saida.lines().firstOrNull { it.trim().startsWith("temperature:") }
        val temp = bruto?.substringAfter(":")?.trim()?.toIntOrNull()?.div(10f)
        val calor = temp?.let { "%.0f°".format(it) } ?: "—"
        val hz = if (PonteLucy.hz > 0) "${PonteLucy.hz} Hz" else "Hz livre"
        val ping = PonteLucy.ping?.let { "$it ms" } ?: "—"
        val stats = "$calor   $hz   ${nomeDriver(PonteLucy.driver)}   $ping"
        val frames = if (pacote != null && pacoteValido(pacote)) jankDe(pacote) else "—"
        val nota = PonteLucy.nota.take(72)
        val extraLinha = if (nota.isBlank()) "Frames ruins $frames" else "Frames ruins $frames\n$nota"
        return Leitura(nome, stats, extraLinha)
    }

    private suspend fun jankDe(pacote: String): String {
        val r = ShizukuManager.executar("dumpsys gfxinfo $pacote", 6_000L)
        if (!r.ok) return "—"
        val m = Regex("""Janky frames:\s*(\d+)\s*\(([\d.]+)%\)""").find(r.saida)
        return if (m != null) "${m.groupValues[2]}%" else "—"
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun mostrar() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tamanho = prefs.getInt("tamanho", 0).coerceIn(0, 2)
        opacidade = prefs.getInt("opacidade", 1).coerceIn(0, 2)
        val lado = dp(listOf(36, 46, 58)[tamanho])

        val rosto = ImageView(this).apply {
            setImageResource(R.drawable.lucy)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF1A0B16.toInt())
                setStroke(dp(1), 0xFFFF4081.toInt())
            }
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            layoutParams = LinearLayout.LayoutParams(lado, lado)
        }
        face = rosto

        val caixa = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            alpha = listOf(0.55f, 0.82f, 1f)[opacidade]
        }
        caixa.addView(rosto)

        titulo = texto(13f, 0xFFFFFFFF.toInt(), true)
        detalhe = texto(12f, 0xFF7EF0FF.toInt(), true)
        extra = texto(11f, 0xFFB8C4D9.toInt(), false)
        painel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0xF0101420.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(dp(248), LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                marginStart = dp(6)
            }
            addView(titulo)
            addView(detalhe)
            addView(extra)
            addView(linhaBotoes(listOf(0 to "Leve", 1 to "Estável", 2 to "Nítido")) { nivel ->
                PonteLucy.driver = nivel
                val acao = PonteLucy.aoDriver
                if (acao != null) acao.invoke(nivel)
                else escopo.launch(Dispatchers.IO) {
                    val janela = ShizukuManager.executar("dumpsys window", 8_000L)
                    val pacote = if (janela.ok) extrairFoco(janela.saida) else null
                    if (pacote != null) aplicarDriverDireto(pacote, nivel)
                }
            })
            addView(linhaBotoes(listOf(0 to "Pequena", 1 to "Média", 2 to "Grande")) { mudarTamanho(it) })
            addView(linhaBotoes(listOf(0 to "Clara", 1 to "Normal", 2 to "Forte")) { mudarOpacidade(it) })
            addView(linhaBotoes(listOf(-1 to "Toque −", 1 to "Toque +")) { passo ->
                escopo.launch(Dispatchers.IO) { ajustarToque(passo) }
            })
        }
        caixa.addView(painel)

        val tipo = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            tipo,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", dp(8))
            y = prefs.getInt("y", dp(96))
        }

        var dx = 0f
        var dy = 0f
        var origemX = 0f
        var origemY = 0f
        rosto.setOnTouchListener { _, ev ->
            val p = params ?: return@setOnTouchListener false
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx = ev.rawX - p.x
                    dy = ev.rawY - p.y
                    origemX = ev.rawX
                    origemY = ev.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (ev.rawX - dx).toInt()
                    p.y = (ev.rawY - dy).toInt()
                    wm?.updateViewLayout(caixa, p)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val arrastou = kotlin.math.abs(ev.rawX - origemX) > dp(6) ||
                        kotlin.math.abs(ev.rawY - origemY) > dp(6)
                    if (!arrastou) {
                        aberto = !aberto
                        painel?.visibility = if (aberto) View.VISIBLE else View.GONE
                    }
                    prefs.edit().putInt("x", p.x).putInt("y", p.y).apply()
                    true
                }
                else -> false
            }
        }

        wm?.addView(caixa, params)
        raiz = caixa
    }

    private fun mudarTamanho(nivel: Int) {
        tamanho = nivel.coerceIn(0, 2)
        prefs.edit().putInt("tamanho", tamanho).apply()
        val lado = dp(listOf(36, 46, 58)[tamanho])
        face?.layoutParams = LinearLayout.LayoutParams(lado, lado)
        face?.requestLayout()
    }

    private fun mudarOpacidade(nivel: Int) {
        opacidade = nivel.coerceIn(0, 2)
        prefs.edit().putInt("opacidade", opacidade).apply()
        raiz?.alpha = listOf(0.55f, 0.82f, 1f)[opacidade]
    }

    private suspend fun ajustarToque(passo: Int) {
        val atual = ShizukuManager.executar("settings get system pointer_speed", 4_000L)
        val n = atual.saida.trim().toIntOrNull() ?: 0
        val prox = (n + passo).coerceIn(-7, 7)
        ShizukuManager.executar("settings put system pointer_speed $prox", 4_000L)
        withContext(Dispatchers.Main) {
            extra?.text = "Toque do sistema em $prox. O layout dos botões continua no jogo."
        }
    }

    private fun linhaBotoes(opcoes: List<Pair<Int, String>>, aoToque: (Int) -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(6), 0, 0)
            opcoes.forEach { (valor, nome) ->
                addView(TextView(this@LucyBolhaService).apply {
                    text = nome
                    setTextColor(0xFF1A0B16.toInt())
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                    setPadding(dp(8), dp(6), dp(8), dp(6))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(12).toFloat()
                        setColor(0xFF00E5FF.toInt())
                    }
                    setOnClickListener { aoToque(valor) }
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                    ).apply { marginEnd = dp(4) }
                })
            }
        }
    }

    private fun texto(sp: Float, cor: Int, umaLinha: Boolean) = TextView(this).apply {
        setTextColor(cor)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        maxLines = if (umaLinha) 1 else 3
        text = "…"
    }

    private fun criarCanal() {
        if (Build.VERSION.SDK_INT < 26) return
        val canal = NotificationChannel(CANAL, "Lucy no jogo", NotificationManager.IMPORTANCE_LOW)
        canal.setShowBadge(false)
        getSystemService(NotificationManager::class.java).createNotificationChannel(canal)
    }

    private fun notificacao(): Notification {
        val abrir = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val b = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CANAL)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return b
            .setSmallIcon(R.drawable.ic_monitor)
            .setContentTitle("Lucy está sobre o jogo")
            .setContentText("Lendo o app da frente, o calor e o driver.")
            .setContentIntent(abrir)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val CANAL = "lucy-bolha"
        const val NOTIF_ID = 41
        @Volatile var ligada: Boolean = false
    }
}

private suspend fun aplicarDriverDireto(pacote: String, nivel: Int) {
    if (!pacoteValido(pacote) || nivel !in 0..2) return
    suspend fun lista(chave: String, incluir: Boolean) {
        val atual = partirLista(ShizukuManager.executar("settings get global $chave", 5_000L).saida)
            .filter { pacoteValido(it) }
            .toMutableList()
        atual.remove(pacote)
        if (incluir) atual.add(pacote)
        val valor = atual.joinToString(",")
        val cmd = if (valor.isBlank()) "settings delete global $chave" else "settings put global $chave $valor"
        if (valor.isBlank() || valor.matches(Regex("^[A-Za-z0-9_.,]+$"))) {
            ShizukuManager.executar(cmd, 5_000L)
        }
    }
    lista("game_driver_opt_in_apps", nivel >= 1)
    lista("game_driver_opt_out_apps", nivel == 0)
    val angulo = valorAngle(nivel)
    val pacotes = partirLista(ShizukuManager.executar("settings get global angle_gl_driver_selection_pkgs", 5_000L).saida)
    val valores = partirLista(ShizukuManager.executar("settings get global angle_gl_driver_selection_values", 5_000L).saida)
    val mapa = LinkedHashMap<String, String>()
    for (i in pacotes.indices) {
        val p = pacotes[i]
        val v = valores.getOrNull(i) ?: continue
        if (pacoteValido(p) && v in setOf("default", "native", "angle")) mapa[p] = v
    }
    mapa[pacote] = angulo
    ShizukuManager.executar(
        "settings put global angle_gl_driver_selection_pkgs ${mapa.keys.joinToString(",")}; " +
            "settings put global angle_gl_driver_selection_values ${mapa.values.joinToString(",")}",
        5_000L,
    )
}
