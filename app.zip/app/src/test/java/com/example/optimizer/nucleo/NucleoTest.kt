package com.example.optimizer.nucleo

import com.example.optimizer.ui.pacoteValido
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NucleoTest {
    @Test
    fun semShizukuNaoInventaDesempenho() {
        val r = diagnosticar(LeituraDiag(shizuku = false, cpu = 0.99f, ram = 0.99f))
        assertEquals(listOf("shizuku"), r.map { it.id })
        assertFalse(r.first().beneficio.contains("FPS", ignoreCase = true))
    }

    @Test
    fun ramAltaSugereLimpezaSemPrometerFps() {
        val r = diagnosticar(LeituraDiag(shizuku = true, ram = 0.9f))
        assertEquals("ram", r.single().id)
        assertTrue(r.single().beneficio.contains("Não promete mais FPS"))
    }

    @Test
    fun semLeituraNaoHaRecomendacao() {
        assertTrue(diagnosticar(LeituraDiag(shizuku = true)).isEmpty())
    }

    @Test
    fun ignorarTiraARecomendacao() {
        val r = diagnosticar(LeituraDiag(shizuku = true, ram = 0.9f), setOf("ram"))
        assertTrue(r.isEmpty())
    }

    @Test
    fun calorComHzAltoSugereBaixar() {
        val r = diagnosticar(LeituraDiag(shizuku = true, tempC = 44f, hz = 120))
        assertEquals("calor", r.single().id)
        assertTrue(r.single().ajuste.contains("90"))
    }

    @Test
    fun guardSobreviveAoTextoENaoRestauraCalado() {
        val livro = GuardLivro()
        livro.registrar(1, "Resolução", "1080x2400", "720x1600", true, true, "wm size reset", "teste")
        val deNovo = livroDoTexto(textoDoLivro(livro.lista()))
        val pendente = deNovo.pendentes().single()
        assertEquals("wm size reset", pendente.comandoRestaurar)
        assertFalse(pendente.restaurado)
        assertEquals(pendente.id, deNovo.marcarRestaurado(pendente.id)?.id)
        assertTrue(deNovo.pendentes().isEmpty())
    }

    @Test
    fun falhaNaoFicaPendente() {
        val livro = GuardLivro()
        livro.registrar(2, "DPI", "", "400", false, true, "wm density reset", "falhou")
        assertTrue(livro.pendentes().isEmpty())
    }

    @Test
    fun perfilFixoNaoSomeEPersonalizadoNaoMandaComando() {
        val originais = perfisOriginais()
        assertEquals(originais, excluirPerfil(originais, "economia"))
        val eco = originais.first { it.id == "economia" }
        assertTrue(comandosDoPerfil(eco).any { it.contains("low_power 1") })
        assertTrue(comandosDoPerfil(eco).any { it.contains("peak_refresh_rate 60") })
        assertTrue(comandosDoPerfil(originais.first { it.id == "personalizado" }).isEmpty())
        val copia = duplicarPerfil(eco, "eco-2", "Eco noite")
        assertEquals(false, copia?.fixo)
        assertNull(duplicarPerfil(eco, "ID inválido", "x"))
    }

    @Test
    fun pacoteInvalidoNaoPassa() {
        assertFalse(pacoteValido("rm -rf"))
        assertFalse(pacoteValido("com.android.systemui;reboot"))
        assertTrue(pacoteValido("com.dts.freefireth"))
    }

    @Test
    fun previaDescreveSemAplicar() {
        val texto = previa(perfisOriginais().first { it.id == "performance" })
        assertTrue(texto.contains("Animação 0"))
        assertFalse(texto.contains("settings put"))
    }

    @Test
    fun restauraOTamanhoQueJaEstava() {
        assertEquals("wm size reset", restaurarTamanho("Physical size: 1080x2400"))
        assertEquals("wm size 720x1600", restaurarTamanho("Physical size: 1080x2400\nOverride size: 720x1600"))
        assertEquals("wm density reset", restaurarDpi("Physical density: 420"))
        assertEquals(
            "settings put global low_power 0",
            restaurarNumero("global", "low_power", "0", setOf("0", "1")),
        )
        assertEquals(
            "settings delete global low_power",
            restaurarNumero("global", "low_power", "null", setOf("0", "1")),
        )
    }
}
